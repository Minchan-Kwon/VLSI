module MulFP(
    input        clk,
    input        rstn,
    input  [7:0] a,
    input  [7:0] b,
    output [7:0] result
);
    // Wires
    wire       signResult;
    wire [3:0] expSum;
    wire [9:0] mantissaProduct;  // Mantissa multiplication result

    // Regs
    reg [7:0] a_reg, b_reg;
    reg [7:0] result_reg;
    reg       carry;
    reg [2:0] expResult;
    reg [3:0] mantissaResult;   // Mantissa post-normalization

    // Sequential Logic
    always @(posedge clk) begin
        if (!rstn) begin
            a_reg      <= 8'b0;
            b_reg      <= 8'b0;
            result_reg <= 8'b0;
        end
        else begin
            a_reg      <= a;
            b_reg      <= b;
            result_reg <= {signResult, expResult, mantissaResult};
        end
    end

    // Floating Point Multiplication
    // ---------   Sign    ---------
    assign signResult = a_reg[7] ^ b_reg[7];

    // --------- Exponent  ---------
    // expSum = expA + expB - bias
    // The bias term is 3 for our FP8 format
    assign expSum = a_reg[6:4] + b_reg[6:4] - 3'd3;

    // --------- Mantissa  ---------
    // Q-format of mantissaProduct is 2.8
    assign mantissaProduct = {1'b1, a_reg[3:0]} * {1'b1, b_reg[3:0]};

    // --------- Normalize ---------
    always @(*) begin
        case (mantissaProduct[9])
            1'b0: begin
                {carry, mantissaResult} = mantissaProduct[7:4] + mantissaProduct[3];
                // Handle mantissa overflow
                if (carry == 1'b1) expResult = expSum[2:0] + 1'b1;
                else expResult = expSum[2:0];
            end
            1'b1: begin
                {carry, mantissaResult} = mantissaProduct[8:5] + mantissaProduct[4];
                expResult = expSum[2:0] + 1'b1;
            end
        endcase
    end
    assign result = result_reg;
endmodule
