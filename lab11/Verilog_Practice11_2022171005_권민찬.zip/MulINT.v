module MulINT(
    input               clk,
    input               rstn,
    input  signed [7:0] a,
    input  signed [7:0] b,
    output signed [15:0] product
);
    reg signed [7:0] a_reg, b_reg;
    reg signed [15:0] product_reg;

    always @(posedge clk) begin
        if (!rstn) begin
            a_reg   <= 8'b0;
            b_reg   <= 8'b0;
            product_reg <= 16'b0;
        end
        else begin
            a_reg <= a;
            b_reg <= b;
            product_reg <= a_reg * b_reg;
        end
    end
    assign product = product_reg;
endmodule