module AddFP(
    input        clk,
    input        rstn,
    input  [7:0] a,
    input  [7:0] b,
    output [7:0] sum
);
    // Wires
    wire [3:0] expDif;
    wire       shift_sel;
    wire [2:0] shift_num;
    wire [2:0] expResult;

    // Regs
    reg carry;
    reg  [2:0] expFinal;
    reg        signResult;
    reg  [7:0] a_reg, b_reg;
    reg  [7:0] result_reg;
    reg [10:0] mantissaResult;
    reg  [9:0] mantissaSmall;
    reg  [9:0] mantissaBig;
    reg  [9:0] mantissaAligned;
    reg  [3:0] mantissaFinal;
    reg [11:0] mantissaSum;

    // Sequential Logic
    always @(posedge clk) begin
        if (!rstn) begin
            a_reg      <= 8'b0;
            b_reg      <= 8'b0;
            result_reg <= 8'b0;
        end
        else begin
            a_reg      <= a;
            b_reg      <= b;
            result_reg <= {signResult, expFinal, mantissaFinal};
        end
    end

    // FP8 Addition
    // ----- Compare Exponent -----
    assign expDif = {1'b0, a_reg[6:4]} - {1'b0, b_reg[6:4]};
    assign shift_sel = expDif[3];            // 1: B > A, 0: A >= B
    assign shift_num = shift_sel ? (~expDif[2:0] + 1'b1) : expDif[2:0];
    // assign shift_num = ~expDif[2:0] + 1'b1;  // Scaling factor: how much to shift

    // --------- Exponent ---------
    assign expResult = shift_sel ? b_reg[6:4] : a_reg[6:4];

    // --------- Mantissa ---------
    always @(*) begin
        // Select mantissa and zero-pad
        if (shift_sel == 1'b1) begin
            mantissaSmall = {1'b1, a_reg[3:0], 5'b0};
            mantissaBig = {1'b1, b_reg[3:0], 5'b0};
        end
        else begin
            mantissaSmall = {1'b1, b_reg[3:0], 5'b0};
            mantissaBig = {1'b1, a_reg[3:0], 5'b0};
        end

        // Scale up
        case (shift_num)
            3'b000: mantissaAligned = mantissaSmall;
            3'b001: mantissaAligned = mantissaSmall >> 1;
            3'b010: mantissaAligned = mantissaSmall >> 2;
            3'b011: mantissaAligned = mantissaSmall >> 3;
            3'b100: mantissaAligned = mantissaSmall >> 4;
            3'b101: mantissaAligned = mantissaSmall >> 5;
            default: mantissaAligned = mantissaSmall;
        endcase

        // Perform signed addition
        case ({shift_sel, a_reg[7], b_reg[7]})
            // shift_sel == 0: mantissaAligned = mantissa of B
            3'b000: mantissaSum = {1'b0, mantissaBig} + {1'b0, mantissaAligned};
            3'b001: mantissaSum = {1'b0, mantissaBig} - {1'b0, mantissaAligned};
            3'b010: mantissaSum = -{1'b0, mantissaBig} + {1'b0, mantissaAligned};
            3'b011: mantissaSum = -{1'b0, mantissaBig} - {1'b0, mantissaAligned};
            // shift_sel == 1: mantissaAligned = mantissa of A
            3'b100: mantissaSum = {1'b0, mantissaAligned} + {1'b0, mantissaBig};
            3'b101: mantissaSum = {1'b0, mantissaAligned} - {1'b0, mantissaBig};
            3'b110: mantissaSum = -{1'b0, mantissaAligned} + {1'b0, mantissaBig};
            3'b111: mantissaSum = -{1'b0, mantissaAligned} - {1'b0, mantissaBig};
        endcase

        if (mantissaSum[11]==1'b1) begin  // Sign is negative
            signResult = 1'b1;
            mantissaResult = -mantissaSum[10:0];
        end
        else begin  // Sign is positive
            signResult = 1'b0;
            mantissaResult = mantissaSum[10:0];
        end
    end

    // --------- Normalize ---------
    always @(*) begin
        casex (mantissaResult[10:9])
            2'b00: begin
                // Need to find exactly where the first 1 appears
                // Slice the mantissaResult and subtract the exponent accordingly
                casex (mantissaResult[8:0])
                    9'b1????????: begin
                        {carry, mantissaFinal} = mantissaResult[7:4] + mantissaResult[3];
                        expFinal = expResult - 1'b1;
                    end
                    9'b01???????: begin
                        {carry, mantissaFinal} = mantissaResult[6:3] + mantissaResult[2];
                        expFinal = expResult - 2'd2;
                    end
                    9'b001??????: begin
                        {carry, mantissaFinal} = mantissaResult[5:2] + mantissaResult[1];
                        expFinal = expResult - 2'd3;
                    end
                    9'b0001?????: begin
                        {carry, mantissaFinal} = mantissaResult[4:1] + mantissaResult[0];
                        expFinal = expResult - 2'd4;
                    end
                    9'b00001????: begin
                        mantissaFinal = mantissaResult[3:0];
                        expFinal = expResult - 2'd5;
                    end
                    default: begin
                        mantissaFinal = 4'b0;
                        expFinal = 3'b0;
                    end
                endcase
            end
            2'b01: begin
                {carry, mantissaFinal} = (mantissaResult[8:5] + mantissaResult[4]);
                // Handle mantissa overflow
                if (carry == 1'b1) expFinal = expResult + 1'b1;
                else expFinal = expResult;
            end
            2'b1x: begin
                {carry, mantissaFinal} = (mantissaResult[9:6] + mantissaResult[5]);
                // Handle mantissa overflow
                if (carry == 1'b1) expFinal = expResult + 1'b10;
                else expFinal = expResult + 1'b1;
            end
        endcase
    end
    assign sum = result_reg;
endmodule