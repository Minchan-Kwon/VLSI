module AddINT(
    input               clk,
    input               rstn,
    input  signed [7:0] a,
    input  signed [7:0] b,
    output signed [8:0] sum
);
    reg signed [7:0] a_reg, b_reg;
    reg signed [8:0] sum_reg;

    always @(posedge clk) begin
        if (!rstn) begin
            a_reg   <= 8'b0;
            b_reg   <= 8'b0;
            sum_reg <= 9'b0;
        end
        else begin
            a_reg <= a;
            b_reg <= b;
            sum_reg <= a_reg + b_reg;
        end
    end

    assign sum = sum_reg;
endmodule