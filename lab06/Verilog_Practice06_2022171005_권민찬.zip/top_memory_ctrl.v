module top_memory_ctrl(
    input clk,
    input rstn,
    output [43:0] out
);
    // Wires
    wire [43:0] mul_out, memory_out;
    wire [21:0] a, b;
    wire [2:0] CA;
    wire [6:0] RA;

    // Regs
    reg [9:0] addr;
    reg [21:0] A_delayed, B_delayed;
    reg [43:0] mul_out_delayed;
    reg [1:0] step;
    reg NCE, NWRT;

    // Memory module 
    rflp1024x44mx3 memory(.DO(memory_out), .DIN(mul_out_delayed), .RA(RA), .CA(CA), .NWRT(NWRT), .NCE(NCE), .CLK(clk));

    // Sequential
    always @(posedge clk) begin
        if (!rstn) begin
            addr <= 10'b0;
            step <= 2'b00;
            NCE <= 1'b1;
            NWRT <= 1'b0;
            A_delayed <= 22'b0;
            B_delayed <= 22'b0;
            mul_out_delayed <= 44'b0;
        end
        
        else begin
            A_delayed <= a;
            B_delayed <= b;
            NCE <= step[1]^step[0];
            NWRT <= ~(step[1] | step[0]);
            mul_out_delayed <= mul_out;
            step <= step + 1'b1;

            // Increment address
            if (!NCE && !NWRT) begin
                addr <= addr + 1;
            end
        end
    end

    // Assign
    assign mul_out = A_delayed * B_delayed;  // Multiplication
    assign {a, b} = memory_out;
    assign RA = addr[9:3];
    assign CA = addr[2:0];
    assign out = memory_out;

endmodule