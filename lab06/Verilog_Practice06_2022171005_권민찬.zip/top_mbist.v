module top_mbist(
    input clk, rstn,
    input MBIST_start,
    output [43:0] Data_out,
    output reg MBIST_done
);
    // Regs
    reg [12:0] counter;
    reg NCE;
    reg running;
    reg [43:0] DATA_in;
    
    // Wires
    wire [9:0] ADDR;
    wire NWRT;
    wire [2:0] state;

    // Memory Module
    rflp1024x44mx3 memory(.DO(Data_out), .DIN(DATA_in), .RA(ADDR[9:3]), .CA(ADDR[2:0]), .NWRT(NWRT), .NCE(NCE), .CLK(clk));

    // Sequential
    always @(posedge clk) begin
        // Synchronouse negative reset
        if (!rstn) begin
            MBIST_done <= 1'b0;
            counter <= 13'b0;
            NCE <= 1'b1;
            running <= 1'b0;
        end

        // Start MBIST 
        else if (MBIST_start) begin
            counter <= 13'b0;
            NCE <= 1'b0;
            MBIST_done <= 1'b0;
            running <= 1'b1;
        end

        // Done logic
        else if (running && state==3'b111 && ADDR==10'h3ff) begin
            MBIST_done <= 1'b1;
            NCE <= 1'b1;
            running <= 1'b0;
        end

        // Counter
        else if (running) begin
            counter <= counter + 1'b1;
        end
    end

    // Combinational
    always @(*) begin
        // MUX
        case(state[2:1])
            2'b00: DATA_in = 44'h000_0000_0000;
            2'b01: DATA_in = 44'hfff_ffff_ffff;
            2'b10: DATA_in = 44'h555_5555_5555;
            2'b11: DATA_in = 44'haaa_aaaa_aaaa;
        endcase
    end

    // Assign state, NWRT, ADDR
    assign state = counter[12:10];
    assign NWRT = counter[10];
    assign ADDR = counter[9:0];
endmodule