`timescale 1ns/10ps 
module stimulus_top_mbist;

    reg clk;
    reg rstn;
    reg MBIST_start;
    wire [43:0] Data_out;
    wire MBIST_done;

    initial begin
        clk <= 1;
        rstn <= 0;
        MBIST_start <= 0;
        #10 rstn <= 1;
        
        #10 MBIST_start <= 1;
        #10 MBIST_start <= 0;

        // 1024 * 8 * 10ns
        #90000 $stop; 
    end
    
    // 10ns clock cycle
    always #5 clk <= ~clk;

    top_mbist TOP_MBIST (
        .clk(clk),
        .rstn(rstn),
        .MBIST_start(MBIST_start),
        .Data_out(Data_out),
        .MBIST_done(MBIST_done)
    );

endmodule