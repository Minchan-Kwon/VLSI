module transpose_fir_synth(
    input                clk,
    input                rstn,
    input  signed [13:0] d_in,
    input  signed [13:0] c0, c1, c2, c3, c4,
    output signed [23:0] result
);
    // Coefficient Registers
    // We only need to store coefficients because the filter module
    // already has registers for the input and output data.
    reg signed [13:0] c0_q, c1_q, c2_q, c3_q, c4_q;

    always @(posedge clk) begin
        if (!rstn) begin
            c0_q <= 14'b0;
            c1_q <= 14'b0;
            c2_q <= 14'b0;
            c3_q <= 14'b0;
            c4_q <= 14'b0;
        end
        else begin
            c0_q <= c0;
            c1_q <= c1;
            c2_q <= c2;
            c3_q <= c3;
            c4_q <= c4;
        end
    end

    // Transposed FIR Filter
    transpose_5tap_fir TRANSPOSED_FIR(.clk(clk), .rstn(rstn), .d_in(d_in), 
                                      .c0(c0_q), .c1(c1_q), .c2(c2_q), .c3(c3_q), 
                                      .c4(c4_q), .result(result));

endmodule