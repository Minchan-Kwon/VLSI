module top_FIR_filter(
    input               clk,
    input               rstn,
    input signed [13:0] c0, c1, c2, c3, c4
);

    // Controller Wires
    wire       rNWRT, wNWRT;
    wire       rNCE,  wNCE;
    wire [7:0] rADDR, wADDR;

    // Memory Wires
    wire [13:0] direct_din_mem;
    wire [13:0] trans_din_mem;

    // FIR Output Wires
    wire [23:0] direct_dout_fir;
    wire [23:0] trans_dout_fir;

    // Controller
    fir_control CONTROL(
        .clk   (clk),
        .rstn  (rstn),
        .rNWRT (rNWRT),
        .wNWRT (wNWRT),
        .rNCE  (rNCE),
        .wNCE  (wNCE),
        .rADDR (rADDR),
        .wADDR (wADDR)
    );

    // Input Memory
    rflp256x14mx4 DIRECT_INPUT_MEM(
        .NWRT (rNWRT), 
        .DIN  (24'b0),
        .RA   (rADDR[7:2]), 
        .CA   (rADDR[1:0]),
        .NCE  (rNCE), 
        .CLK  (clk), 
        .DO   (direct_din_mem)
    );

    rflp256x14mx4 TRANS_INPUT_MEM(
        .NWRT (rNWRT), 
        .DIN  (24'b0), 
        .RA   (rADDR[7:2]), 
        .CA   (rADDR[1:0]), 
        .NCE  (rNCE), 
        .CLK  (clk), 
        .DO   (trans_din_mem)
    );

    // FIR Filter
    direct_5tap_fir DIRECT_FIR(
        .clk    (clk), 
        .rstn   (rstn), 
        .d_in   (direct_din_mem[13:0]), 
        .c0     (c0), .c1(c1), .c2(c2), .c3(c3), .c4(c4), 
        .result (direct_dout_fir)
    );

    transpose_5tap_fir TRANS_FIR(
        .clk    (clk), 
        .rstn   (rstn), 
        .d_in   (trans_din_mem[13:0]), 
        .c0     (c0), .c1(c1), .c2(c2), .c3(c3), .c4(c4), 
        .result (trans_dout_fir)
    );

    // Write Memory
    rflp256x24mx4 DIRECT_OUTPUT_MEM(
        .NWRT (wNWRT), 
        .DIN  (direct_dout_fir), 
        .RA   (wADDR[7:2]), 
        .CA   (wADDR[1:0]), 
        .NCE  (wNCE), 
        .CLK  (clk), 
        .DO   ()
    );

    rflp256x24mx4 TRANS_OUTPUT_MEM(
        .NWRT (wNWRT), 
        .DIN  (trans_dout_fir), 
        .RA   (wADDR[7:2]), 
        .CA   (wADDR[1:0]), 
        .NCE  (wNCE), 
        .CLK  (clk), 
        .DO   ()
    );

endmodule