module transpose_5tap_fir(
    input                clk,
    input                rstn,
    input  signed [13:0] d_in,
    input  signed [13:0] c0, c1, c2, c3, c4,
    output signed [23:0] result
);
    // Registers
    reg signed [13:0] x0;
    reg signed [21:0] x1; 
    reg signed [22:0] x2, x3; 
    reg signed [23:0] x4;
    reg signed [23:0] d_out;
    
    // Wires
    wire signed [27:0] mul_0_out, mul_1_out, mul_2_out, mul_3_out, mul_4_out;
    wire signed [21:0] round_0_out, round_1_out, round_2_out, round_3_out, round_4_out;
    wire signed [22:0] adder_0_out, adder_1_out;
    wire signed [23:0] adder_2_out, adder_3_out;

    // Delay Line
    always @(posedge clk) begin
        if (!rstn) begin
            x0 <= 14'b0;
            x1 <= 22'b0;
            x2 <= 23'b0;
            x3 <= 23'b0;
            x4 <= 24'b0;
            d_out <= 24'b0;
        end
        else begin
            x0 <= d_in;
            x1 <= round_4_out;
            x2 <= adder_0_out;
            x3 <= adder_1_out;
            x4 <= adder_2_out;
            d_out <= adder_3_out;
        end
    end

    // Multiplication
    assign mul_0_out = x0 * c0;
    assign mul_1_out = x0 * c1;
    assign mul_2_out = x0 * c2;
    assign mul_3_out = x0 * c3;
    assign mul_4_out = x0 * c4;

    // Rounding Units
    round_unit R0(.in(mul_0_out), .out(round_0_out));
    round_unit R1(.in(mul_1_out), .out(round_1_out));
    round_unit R2(.in(mul_2_out), .out(round_2_out));
    round_unit R3(.in(mul_3_out), .out(round_3_out));
    round_unit R4(.in(mul_4_out), .out(round_4_out));

    // Addition of Results
    // Automatic Sign Extension
    assign adder_0_out = x1 + round_3_out;
    assign adder_1_out = x2 + round_2_out;
    assign adder_2_out = x3 + round_1_out;
    assign adder_3_out = x4 + round_0_out;

    // Output Assignment
    assign result = d_out;

endmodule