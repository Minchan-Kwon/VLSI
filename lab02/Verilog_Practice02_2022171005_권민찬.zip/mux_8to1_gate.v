module mux_8to1_gate(
    input s2, // s2 is the MSB of the select signal
    input s1,
    input s0,
    input d0,
    input d1,
    input d2,
    input d3,
    input d4,
    input d5,
    input d6,
    input d7,
    output out
);
    // Wires
    wire s2n, s1n, s0n;
    wire a0, a1, a2, a3, a4, a5, a6, a7;

    // Inverters
    not (s2n, s2);
    not (s1n, s1);
    not (s0n, s0);

    // Select one input
    and (a0, s2n, s1n, s0n, d0);
    and (a1, s2n, s1n, s0,  d1);
    and (a2, s2n, s1,  s0n, d2);
    and (a3, s2n, s1,  s0,  d3);
    and (a4, s2,  s1n, s0n, d4);
    and (a5, s2,  s1n, s0,  d5);
    and (a6, s2,  s1,  s0n, d6);
    and (a7, s2,  s1,  s0,  d7);

    // Combine all
    or  (out, a0, a1, a2, a3, a4, a5, a6, a7);

endmodule
