module rca_22bit_ff(
    input clk,
    input rstn,
    input [21:0] a, b,
    input cin,
    output [21:0] sum,
    output cout
);
    // Define regs for input and output stages
    reg [21:0] a_ff, b_ff;
    reg cin_ff;
    reg [21:0] sum_ff;
    reg cout_ff;

    // Define wires for the output pins
    wire [21:0] sum_wire;
    wire cout_wire;

    // Instantiate 22bit ripple carry adder module
    rca_22bit add0(.a(a_ff), .b(b_ff), .cin(cin_ff), .sum(sum_wire), .cout(cout_wire));

    // Sequential logic
    always @(posedge clk) begin
        if (!rstn) begin
            a_ff <= 22'b0;
            b_ff <= 22'b0;
            cin_ff <= 0;
            sum_ff <= 22'b0;
            cout_ff <= 0;
        end
        else begin
        a_ff <= a;
        b_ff <= b;
        cin_ff <= cin;
        sum_ff <= sum_wire;
        cout_ff <= cout_wire;
        end
    end

    // Connect the output stage registers to the output ports
    assign sum = sum_ff;
    assign cout = cout_ff;

endmodule

