module rca_22bit(
    input [21:0] a, b,
    input cin,
    output [21:0] sum,
    output cout
);
    wire [22:0] carry;
    // Assign initial carry_in
    assign carry[0] = cin;

    // Instantiate 22 FA modules
    genvar i;
    generate 
        for(i = 0; i < 22; i = i + 1) begin : fa_gen
            fa u_fa(.a(a[i]), .b(b[i]), .cin(carry[i]), 
                .sum(sum[i]), .cout(carry[i+1]));
        end
    endgenerate

    // Assign carry_out
    assign cout = carry[22];
endmodule
