
`timescale 1 ns / 1 ps
module stimulus_rca;

wire [23-1:0] sum;
reg [22-1:0] a, b;
reg [23-1:0] mat_sum [0:99];
reg [23-1:0] mat_sum_cmp;
reg [22-1:0] mat_a [0:99];
reg [22-1:0] mat_b [0:99];

rca_22bit add0(.sum(sum[21:0]), .a(a), .b(b), .cin(1'b0), .cout(sum[22]));

integer i;
integer err;
initial
begin
    $readmemh("a_input.txt", mat_a);
    $readmemh("b_input.txt", mat_b);
    $readmemh("sum_output.txt", mat_sum);

    i = 0;
    err = 0;
    #(10);

    for(i=0 ; i<100 ; i=i+1) begin
        a = mat_a[i];
        b = mat_b[i];
        #(0)
        mat_sum_cmp = mat_sum[i];
        if(sum != mat_sum_cmp) err = err + 1;#(10);
    end
    #(20)
    $stop;
end
endmodule