`timescale 1 ns / 1 ps
module stimulus_mux8to1;

reg i0, i1, i2, i3, i4, i5, i6, i7;
reg s0, s1, s2;
wire gate_out0, gate_out1, behav_out;

mux_8to1_gate gate0(.out(gate_out0), .d0(i0), .d1(i1), .d2(i2), .d3(i3), .d4(i4), .d5(i5),
.d6(i6), .d7(i7), .s2(s2), .s1(s1), .s0(s0));

mux_8to1 gate1 (.out(gate_out1), .d0(i0), .d1(i1), .d2(i2), .d3(i3), .d4(i4), .d5(i5),
.d6(i6), .d7(i7), .s2(s2), .s1(s1), .s0(s0));

mux_8to1_behavioral behav0 (.out(behav_out), .d0(i0), .d1(i1), .d2(i2), .d3(i3), .d4(i4), .d5(i5),
.d6(i6), .d7(i7), .s2(s2), .s1(s1), .s0(s0));

always #10 s0 = ~s0;
always #20 s1 = ~s1;
always #40 s2 = ~s2;

initial
begin
    {i0, i1, i2, i3, i4, i5, i6, i7} = 8'b01010101;
    {s0, s1, s2} = 3'b0;
    #200
    $stop;
end

endmodule