module mux_4to1(
    input s1, 
    input s0,
    input d0,
    input d1,
    input d2,
    input d3,
    output out
);
    wire s0n, s1n;
    wire y0, y1, y2, y3;

    // ~s0 and ~s1
    not(s0n, s0);
    not(s1n, s1);

    // And the input data with select bit
    and(y0, d0, s1n, s0n);
    and(y1, d1, s1n, s0);
    and(y2, d2, s1, s0n);
    and(y3, d3, s1, s0);

    // Or the wires for the final output signal
    or(out, y0, y1, y2, y3);

endmodule