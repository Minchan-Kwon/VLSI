module mux_8to1(
    input s2, // s2 is the MSB of the select signal
    input s1,
    input s0,
    input d0,
    input d1,
    input d2,
    input d3,
    input d4,
    input d5,
    input d6,
    input d7,
    output out
);
    wire mux0_out, mux1_out;
    wire mux0_and, mux1_and;
    wire s2n;

    // 4to1 Mux
    mux_4to1 mux0(.s1(s1), .s0(s0), .d0(d0), .d1(d1), 
                    .d2(d2), .d3(d3), .out(mux0_out));
    mux_4to1 mux1(.s1(s1), .s0(s0), .d0(d4), .d1(d5), 
                    .d2(d6), .d3(d7), .out(mux1_out));

    not(s2n, s2);

    and(mux0_and, s2n, mux0_out);
    and(mux1_and, s2, mux1_out);

    or(out, mux0_and, mux1_and);

endmodule
