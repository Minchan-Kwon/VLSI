module fa(
    input a,
    input b,
    input cin,
    output sum,
    output cout
);
    wire a_and_b;
    wire a_xor_b;
    wire cin_and_ab;

    // Sum logic
    xor(sum, a, b, cin);

    // Carry logic
    and(a_and_b, a, b);             // a & b
    xor(a_xor_b, a, b);             // a ^ b
    and(cin_and_ab, cin, a_xor_b);  // cin & (a ^ b)
    or(cout, a_and_b, cin_and_ab);
endmodule
