module sqrt_carry_select_adder_22b(
    input         clk,
    input         rstn,
    input [21:0]  a,
    input [21:0]  b,
    input         cin,
    output [21:0] sum,
    output        cout
);
    // Wires for the output pin of the instance
    wire [21:0] sum_wire;
    wire        cout_wire;

    // Internal regs 
    reg [21:0] a_ff, b_ff, sum_ff;
    reg [22:0] carry;
    reg        cin_ff, cout_ff;

    // Square-root CSA instance
    sqrt_csa csa(.a(a_ff), .b(b_ff), .cin(cin_ff), .sum(sum_wire), .cout(cout_wire));

    always @(posedge clk) begin
        if (!rstn) begin
            a_ff <= 0;
            b_ff <= 0;
            cin_ff <= 0;
            sum_ff <= 0;
            cout_ff <= 0;
        end
        else begin
            a_ff <= a;
            b_ff <= b;
            cin_ff <= cin;
            sum_ff <= sum_wire;
            cout_ff <= cout_wire;
        end
    end

    assign sum = sum_ff;
    assign cout = cout_ff;

endmodule