module low_cost_transpose_fir(
    input                clk,
    input                rstn,
    input  signed [13:0] d_in,
    output signed [23:0] result
);
    // Registers
    reg signed [13:0] X_N;
    reg signed [21:0] y_4_reg;
    reg signed [22:0] y_3_reg, y_2_reg;
    reg signed [23:0] y_1_reg, y_0_reg;

    // Wires
    wire signed [27:0] A, B, C, D;
    wire signed [27:0] y_0, y_1, y_2, y_3, y_4;
    wire signed [21:0] y_0_round, y_1_round, y_2_round, y_3_round, y_4_round;

    // Common Bit Patterns A, B, C, D
    // A, B, C, D are sign extended to 28-bits
    assign A = (X_N <<< 2) - X_N; // X_N << 2 - X_N 
    assign B = (X_N <<< 8) + (X_N <<< 6); // X_N << 8 + X_N << 6
    assign C = (X_N <<< 3) - X_N; // X_N << 3 - X_N
    assign D = X_N; // X_N

    // Per-tap Computation Results
    assign y_0 = A + (A << 7) + (D << 11);
    assign y_1 = -(A << 2) - B - (A << 10);
    assign y_2 = -A + (D << 7) + (D << 12);
    assign y_3 = -D + (B << 1) - (D << 12);
    assign y_4 = C + (C << 6) + (A << 11);

    // Rounding Units
    round_unit R0(.in(y_0), .out(y_0_round));
    round_unit R1(.in(y_1), .out(y_1_round));
    round_unit R2(.in(y_2), .out(y_2_round));
    round_unit R3(.in(y_3), .out(y_3_round));
    round_unit R4(.in(y_4), .out(y_4_round));

    // Delay Line
    always @(posedge clk) begin
        if (!rstn) begin
            X_N     <= 14'b0;
            y_4_reg <= 22'b0;
            y_3_reg <= 23'b0;
            y_2_reg <= 23'b0;
            y_1_reg <= 24'b0;
            y_0_reg <= 24'b0;
        end
        else begin
            X_N     <= d_in;
            y_4_reg <= y_4_round;
            y_3_reg <= y_4_reg + y_3_round;
            y_2_reg <= y_3_reg + y_2_round;
            y_1_reg <= y_2_reg + y_1_round;
            y_0_reg <= y_1_reg + y_0_round;
        end
    end

    // Assign Output
    assign result = y_0_reg;
endmodule