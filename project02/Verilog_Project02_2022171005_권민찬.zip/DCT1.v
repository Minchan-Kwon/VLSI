module DCT1 #(
    parameter IN_BW = 8,   // Input data bit width
    parameter OUT_BW = 10  // output data bit width
)(
    input   [16*IN_BW-1:0] X,
    output [12*OUT_BW-1:0] Z
);  
    // Input vector elements
    wire signed [IN_BW:0] x0, x1, x2, x3, x4, x5, x6, x7;
    wire signed [IN_BW:0] x8, x9, x10, x11, x12, x13, x14, x15;

    // Sum of two inputs
    wire signed [IN_BW+1:0] s2_0, s2_1, s2_2, s2_3, s2_4, s2_5, s2_6, s2_7;
    // Difference of two inputs
    wire signed [IN_BW+1:0] d2_0, d2_1, d2_2, d2_3, d2_4, d2_5, d2_6, d2_7;
    // Sum of four inputs
    wire signed [IN_BW+2:0] s4_0, s4_1, s4_2, s4_3;
    // Difference of four inputs
    wire signed [IN_BW+2:0] d4_0, d4_1, d4_2, d4_3;

    // Product of the difference of inputs (d2_n) and the 
    // common pattern of the coefficient (101) which appear
    // in c1, c3, c5, c11
    wire signed [IN_BW+3:0] p0, p1, p2, p3, p4, p5, p6, p7;

    // DCT output
    // Pre-truncation (12.5 format)
    // Element-wise product requires 7 bits for integer,
    // 5 bits for decimal, and 1 sign bit (8.5 format).
    // This is because the coefficients are all less than 0.5.
    // Summing the products requires log(16) = 4 additional bits.
    wire signed [IN_BW+5+4-1:0] m0, m1, m2, m3, m4, m5, m6, m7;
    wire signed [IN_BW+5+4-1:0] m8, m9, m10, m11, m12, m13, m14, m15;
    // Post-truncation
    wire signed [OUT_BW-1:0] z0, z1, z2, z3, z4, z5, z6, z7;
    wire signed [OUT_BW-1:0] z8, z9, z10, z11, z12, z13, z14, z15;

    // Sign extend the inputs (inputs are positive pixel magnitudes)
    assign x0  = {1'b0, X[16*IN_BW-1:15*IN_BW]};
    assign x1  = {1'b0, X[15*IN_BW-1:14*IN_BW]};
    assign x2  = {1'b0, X[14*IN_BW-1:13*IN_BW]};
    assign x3  = {1'b0, X[13*IN_BW-1:12*IN_BW]};
    assign x4  = {1'b0, X[12*IN_BW-1:11*IN_BW]};
    assign x5  = {1'b0, X[11*IN_BW-1:10*IN_BW]};
    assign x6  = {1'b0, X[10*IN_BW-1:9*IN_BW]};
    assign x7  = {1'b0, X[ 9*IN_BW-1:8*IN_BW]};
    assign x8  = {1'b0, X[ 8*IN_BW-1:7*IN_BW]};
    assign x9  = {1'b0, X[ 7*IN_BW-1:6*IN_BW]};
    assign x10 = {1'b0, X[ 6*IN_BW-1:5*IN_BW]};
    assign x11 = {1'b0, X[ 5*IN_BW-1:4*IN_BW]};
    assign x12 = {1'b0, X[ 4*IN_BW-1:3*IN_BW]};
    assign x13 = {1'b0, X[ 3*IN_BW-1:2*IN_BW]};
    assign x14 = {1'b0, X[ 2*IN_BW-1:1*IN_BW]};
    assign x15 = {1'b0, X[ 1*IN_BW-1:0]};

    // Get the multiplication results
    // Share the addition results instead of having to add
    // them over and over again.
    assign s2_0 = x0 + x15;
    assign s2_1 = x1 + x14;
    assign s2_2 = x2 + x13;
    assign s2_3 = x3 + x12;
    assign s2_4 = x4 + x11;
    assign s2_5 = x5 + x10;
    assign s2_6 = x6 + x9;
    assign s2_7 = x7 + x8;

    assign d2_0 = x0 - x15;
    assign d2_1 = x1 - x14;
    assign d2_2 = x2 - x13;
    assign d2_3 = x3 - x12;
    assign d2_4 = x4 - x11;
    assign d2_5 = x5 - x10;
    assign d2_6 = x6 - x9;
    assign d2_7 = x7 - x8;

    assign s4_0 = s2_0 + s2_7;  // x0+x15+x7+x8
    assign s4_1 = s2_1 + s2_6;  // x1+x14+x6+x9
    assign s4_2 = s2_2 + s2_5;  // x2+x13+x5+x10
    assign s4_3 = s2_3 + s2_4;  // x3+x12+x4+x11

    assign d4_0 = s2_0 - s2_7;  // x0+x15-x7-x8
    assign d4_1 = s2_1 - s2_6;  // x1+x14-x6-x9
    assign d4_2 = s2_2 - s2_5;  // x2+x13-x5-x10
    assign d4_3 = s2_3 - s2_4;  // x3+x12-x4-x11

    // c1, c3, c5, c11 share a bit pattern of 101,
    // We can exploit this repeating pattern.
    assign p0 = (d2_0 << 2) + d2_0;  // (x0-x15) * 101
    assign p1 = (d2_1 << 2) + d2_1;  // (x1-x14) * 101
    assign p2 = (d2_2 << 2) + d2_2;  // (x2-x13) * 101
    assign p3 = (d2_3 << 2) + d2_3;  // (x3-x12) * 101
    assign p4 = (d2_4 << 2) + d2_4;  // (x4-x11) * 101
    assign p5 = (d2_5 << 2) + d2_5;  // (x5-x10) * 101
    assign p6 = (d2_6 << 2) + d2_6;  // (x6-x9) * 101
    assign p7 = (d2_7 << 2) + d2_7;  // (x7-x8) * 101

    // Adder shift tree
    // Explicitly use parentheses to balance the adder tree
    // Group the summations by the number of shifts
    assign m0  = ((s4_0 + s4_3) + (s4_1 + s4_2)) << 3;
    assign m1  = ((((d2_0 + d2_1) << 4) - (p0 + p1)) + (((d2_3 + d2_4) << 3) + (d2_6 << 2))) + 
                 (((p2 << 1) + d2_3) - ((d2_4 + d2_6) - d2_7));
    assign m2  = (((d4_0 + d4_1) << 3) + (d4_2 << 2)) + (((d4_0 + d4_2 + d4_3) << 1) + (d4_0 + d4_1));
    assign m3  = ((((d2_0 - d2_5) << 4) + ((d2_1 - d2_6) << 3)) - ((p0 - p5) + (p4 << 1))) - 
                 (((d2_7 << 2) + (d2_1 - d2_2)) + ((p3 + d2_6) - d2_7));
    assign m4  = (((s4_0 - s4_3) << 3) + ((s4_0 - s4_3) << 1)) + ((s4_1 - s4_2) << 2);
    assign m5  = ((((d2_6 - d2_3) << 4) + (((d2_0 - d2_2) + d2_5) << 3)) - ((d2_4 << 2) - (p3 - p6))) + 
                 ((p7 + (d2_0 << 1)) + ((d2_1 - d2_2) + (d2_4 - d2_5)));
    assign m6  = (((d4_0 - d4_2) << 3) - (d4_3 << 2)) - (((d4_1 + d4_2 + d4_3) << 1) - (d4_0 - d4_2));
    assign m7  = ((((d2_4 - d2_2) << 4) + (((d2_0 - d2_6) - d2_7) << 3)) + ((d2_5 << 2) - (d2_6 << 1))) - 
                 (((p1 - p2) + p4) - (((d2_0 + d2_3) - d2_5) + d2_7));
    assign m8  = ((s4_0 + s4_3) - (s4_1 + s4_2)) << 3;
    assign m9  = ((((d2_3 - d2_5) << 4) + (((d2_0 - d2_1) + d2_7) << 3)) - ((d2_2 << 2) + (d2_1 << 1))) - 
                 (((p3 - p5) - p6) + (((d2_0 - d2_2) + d2_4) - d2_7));
    assign m10 = (((d4_3 - d4_1) << 3) + (d4_0 << 2)) + (((d4_0 - d4_1 + d4_2) << 1) + (d4_3 - d4_1));
    assign m11 = (((((d2_2 + d2_5) - d2_7) << 3) - ((d2_1 + d2_4) << 4)) + ((d2_3 << 2) - (d2_7 << 1))) + 
                 (((p0 + p1) + p4) - (((d2_2 + d2_3) - d2_5) - d2_6));
    


    // Truncate the results
    // The integer LSB is lost. 
    // Slice the bits accordingly in the 2D-DCT module
    assign z0  = m0[15:6];
    assign z1  = m1[15:6];
    assign z2  = m2[15:6];
    assign z3  = m3[15:6];
    assign z4  = m4[15:6];
    assign z5  = m5[15:6];
    assign z6  = m6[15:6];
    assign z7  = m7[15:6];
    assign z8  = m8[15:6];
    assign z9  = m9[15:6];
    assign z10 = m10[15:6];
    assign z11 = m11[15:6];

    // Assign to output
    // Output Q-format is 10.0
    // The integer LSB is lost!
    assign Z = {z0, z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11};

endmodule