module DCT_TOP (
    input clk,
    input rstn
);
    // Wires
    // Control signals
    wire [13:0] ADDR_READ, ADDR_WRT;
    wire        NCE_READ, NCE_WRT;
    wire        SEL_LoF;
    wire        EN_TP1, EN_TP2;
    // Datapath
    wire  [16*8-1:0] DCT1_IN;
    wire [12*10-1:0] DCT1_OUT;
    wire [16*10-1:0] TP1_OUT;
    wire [12*12-1:0] DCT2_OUT;
    wire [12*12-1:0] TP2_OUT;

    // Regs

    // Control Unit
    DCTControl CONTROL(
        .clk(clk),
        .rstn(rstn),
        .ADDR_READ(ADDR_READ),
        .ADDR_WRT(ADDR_WRT),
        .NCE_READ(NCE_READ),
        .NCE_WRT(NCE_WRT),
        .SEL_LoF(SEL_LoF),
        .EN_TP1(EN_TP1),
        .EN_TP2(EN_TP2)
    );

    // Input RAM
    rflp16384x128mx16 RAM_IN(
        .DO(DCT1_IN),
        .DIN(),
        .RA(ADDR_READ[13:4]),
        .CA(ADDR_READ[3:0]),
        .NWRT(1'b1),
        .NCE(NCE_READ),
        .CLK(clk)
    );

    // 1D-DCT module
    // 16x1 Vector -> 12x1 Vector
    DCT1 DCT_1D(.X(DCT1_IN), .Z(DCT1_OUT));

    // First transposed memory
    // 16x16
    TPMEM1 TPMEM1(
        .i_data(DCT1_OUT),
        .i_enable(EN_TP1),
        .i_clk(clk),
        .i_Reset(rstn),
        .o_data(TP1_OUT)
    );

    // 2D-DCT module
    // 16x1 Vector -> 12x1 Vector
    DCT2 DCT_2D(.X(TP1_OUT), .sel(SEL_LoF), .Z(DCT2_OUT));

    // Second transposed memory
    // 12x12
    TPMEM2 TPMEM2(
        .i_data(DCT2_OUT),
        .i_enable(EN_TP2),
        .i_clk(clk),
        .i_Reset(rstn),
        .o_data(TP2_OUT)
    );

    // Output RAM
    rflp16384x192mx16 RAM_OUT(
        .DO(),
        .DIN({TP2_OUT, 48'b0}),
        .RA(ADDR_WRT[13:4]),
        .CA(ADDR_WRT[3:0]),
        .NWRT(1'b0),
        .NCE(NCE_WRT),
        .CLK(clk)
    );

endmodule