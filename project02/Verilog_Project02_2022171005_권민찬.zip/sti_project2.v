`timescale 1ns / 10ps
module sti_project2;

reg clk;
reg rstn;

DCT_TOP top(clk, rstn); // define input & output ports of your top module by yourself

always #5 clk <= ~clk;

integer img_idx;
integer mem_idx;
integer fp;

// Use string registers for dynamic file names
// 8 bits per character, 20 characters maximum length
reg [8*20:1] img_in_name;
reg [8*20:1] img_out_name;

initial begin
    clk = 1;

    // Loop through image 1 to 8
    for (img_idx = 1; img_idx <= 8; img_idx = img_idx + 1) begin
        
        // Generate dynamic file names for input and output
        $sformat(img_in_name, "image_in_%0d.txt", img_idx);
        $sformat(img_out_name, "DCT_image_%0d.txt", img_idx);
        
        $display("============================================");
        $display("Starting simulation for: %s", img_in_name);

        // Assert reset to clear previous states of the DCT module
        // This is strictly required before loading a new image
        rstn = 0;
        
        // Load the new input image
        $readmemh(img_in_name, top.RAM_IN.array); // check the path of memory location
        #10;
        
        // Release reset to start module operation
        rstn = 1;

        // Wait for 2D-DCT operations to finish (change if you need)
        #164210;

        // Open output file and write results
        fp = $fopen(img_out_name, "w");
        for (mem_idx = 0; mem_idx < 16384; mem_idx = mem_idx + 1) begin
            $fwrite(fp, "%b\n", top.RAM_OUT.array[mem_idx]); // check the path of memory location
        end
        
        #100;
        $fclose(fp);

        $display("Finished writing to: %s", img_out_name);
        $display("============================================");
    end

    $display("All 8 images have been processed successfully.");
    $finish;
end

endmodule