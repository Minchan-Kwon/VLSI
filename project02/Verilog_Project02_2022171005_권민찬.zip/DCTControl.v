module DCTControl(
    input         clk,
    input         rstn,
    output [13:0] ADDR_READ,
    output [13:0] ADDR_WRT,
    output        NCE_READ,
    output        NCE_WRT,
    output        SEL_LoF,
    output        EN_TP1,  // The enable signal to start the internal counter in TPMEM1
    output        EN_TP2   // The enable signal to start the internal counter in TPMEM2
);
    reg        RUN;
    reg [14:0] counter;  // 15-bit counter

    // Counter logic
    always @(posedge clk) begin
        if (!rstn) begin
            RUN     <= 1'b0;
            counter <= 15'b0;
        end
        else begin
            if (!RUN) begin
                // start
                RUN <= 1'b1;
            end
            else begin
                // Running
                if (counter == 35 + 16*1024) begin
                    // Termination condition
                    // Final write to the output RAM finishes after 
                    // (36+16*1024)th cycle. The counter value at
                    // the (36+16*1024)th cycle is 35+16*1024.
                    RUN     <= 1'b0;
                    counter <= 15'b0;
                end
                else begin
                    counter <= counter + 1'b1;
                end
            end
        end
    end


// RAM NCE
assign NCE_READ = (counter >= 16*1024);
assign NCE_WRT  = (counter <= 34) | (counter >= 35 + 16*1024) | (~RUN);

// Address
assign ADDR_READ = counter[13:0];
assign ADDR_WRT  = counter[13:0] - 14'd35;

// TPMEM Enable
assign EN_TP1 = (counter >= 15'b1);
assign EN_TP2 = (counter >= 15'd18);

// DC Signal select
assign SEL_LoF = ((counter) % 16 == 2);
endmodule