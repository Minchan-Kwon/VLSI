module DCT_TOP #(
    parameter BW = 10,
    parameter MEM_SIZE = 12
)(
    input              clk,
    input              rstn,
    input   [16*8-1:0] D_IN,
    output [16*12-1:0] D_OUT
);
    // Wires
    // Control signals
    wire [13:0] ADDR_READ, ADDR_WRT;
    wire        NCE_READ, NCE_WRT;
    wire        SEL_LoF;
    wire        EN_TP1, EN_TP2;
    // Datapath
    wire [12*10-1:0] DCT1_OUT;
    wire [16*10-1:0] TP1_OUT;
    wire [12*12-1:0] DCT2_OUT;
    wire [12*12-1:0] TP2_OUT;

    // Regs
    reg  [16*8-1:0] IN_REG;
    reg [16*12-1:0] OUT_REG;

    // Control Unit
    DCTControl CONTROL(
        .clk(clk),
        .rstn(rstn),
        .ADDR_READ(ADDR_READ),
        .ADDR_WRT(ADDR_WRT),
        .NCE_READ(NCE_READ),
        .NCE_WRT(NCE_WRT),
        .SEL_LoF(SEL_LoF),
        .EN_TP1(EN_TP1),
        .EN_TP2(EN_TP2)
    );

    // Input Registers
    always @(posedge clk) begin
	if (!rstn) begin
	    IN_REG <= 128'b0;
	end
	else begin
	    IN_REG <= D_IN;
	end
    end

    // 1D-DCT module
    // IO bit width 명시
    DCT1 DCT_1D(.X(IN_REG), .Z(DCT1_OUT));

    // First transposed memory
    // 16x16
    TPMEM1 TPMEM1(
        .i_data(DCT1_OUT),
        .i_enable(EN_TP1),
        .i_clk(clk),
        .i_Reset(rstn),
        .o_data(TP1_OUT)
    );

    // 2D-DCT module
    // IO bit width 명시
    DCT2 DCT_2D(.X(TP1_OUT), .sel(SEL_LoF), .Z(DCT2_OUT));

    // Second transposed memory
    // 12x12
    TPMEM2 TPMEM2(
        .i_data(DCT2_OUT),
        .i_enable(EN_TP2),
        .i_clk(clk),
        .i_Reset(rstn),
        .o_data(TP2_OUT)
    );

    // Output RAM
    always @(posedge clk) begin
	if (!rstn) begin
	    OUT_REG <= 192'b0;    
	end
	else begin
	    OUT_REG <= {TP2_OUT, 48'b0};
	end	
    end

    assign D_OUT = OUT_REG;

endmodule
