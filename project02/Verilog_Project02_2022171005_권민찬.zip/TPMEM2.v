module TPMEM2
#( parameter BW = 12,
   parameter SIZE = 12 )
    // SIZE stands for the number of elements in the input vector
    // BW stays at 12 - the matlab code expects 12-bit integers

(  input        [SIZE*BW-1:0] i_data,
   input                      i_enable,
   input                      i_clk,
   input                      i_Reset,
   output reg   [SIZE*BW-1:0] o_data
);

reg [5-1:0]         counter;
reg [SIZE*BW-1:0]   array   [SIZE-1:0];      // Array to store data
reg [SIZE*BW-1:0]   data_out;                // Data that has been read       

wire [SIZE*BW-1:0]  col     [SIZE-1:0];      // Column-wise data
wire [4-1:0]        index = counter[4-1:0];  // Address

// Counter and IO 
always @(posedge i_clk) begin
    if (!i_Reset) begin
        counter <= 5'b0;
        o_data <= {SIZE*BW{1'b0}};
    end
    else begin
        o_data <= data_out;
        if (i_enable)
            counter <= counter + 5'b1;
    end
end

// Read the data
always @(*) begin
    if (index < SIZE) begin
        // Valid index (0 ~ SIZE-1)
        if (counter[4] == 1'b0) begin
            // MSB of counter == 0: Row-wise read
            data_out = array[index];
        end
        else begin
            // MSB of counter == 1: Column-wise read
            data_out = col[index];
        end
    end
    else begin
        // Invalid index
        // Output 0 when index is invalid
        data_out = {SIZE*BW{1'b0}};
    end
end

// Write the input data
genvar r, c;
generate
    for (r = 0; r < SIZE; r = r + 1) begin : gen_write_row
        for (c = 0; c < SIZE; c = c + 1) begin : gen_write_col
            always @(posedge i_clk) begin
                if (~i_Reset) begin
                    // Reset the array
                    array[r][(SIZE-c)*BW-1 -: BW] <= {BW{1'b0}};
                end
                else if (i_enable && index < SIZE) begin
                    // MSB of counter == 0: Row-wise write
                    // Access the array with the variable 'c'
                    // instead of the dynamic register value 'index'
                    if (counter[4] == 1'b0 && index == r) begin
                        array[r][(SIZE-c)*BW-1 -: BW] <= i_data[(SIZE-c)*BW-1 -: BW];
                    end
                    // MSB of counter == 1: column-wise write
                    // Access the array with the variable 'c'
                    // instead of the dynamic register value 'index'
                    else if (counter[4] == 1'b1 && index == c) begin
                        array[r][(SIZE-c)*BW-1 -: BW] <= i_data[(SIZE-r)*BW-1 -: BW];
                    end
                end
            end
        end
    end
endgenerate

// Column-wise data assignment
// 'col' is an array of the transposed data
// Column-wise read is available by accessing col[]
generate
    for (c = 0; c < SIZE; c = c + 1) begin : gen_col
        for (r = 0; r < SIZE; r = r + 1) begin : gen_row
            assign col[c][(SIZE-r)*BW-1 -: BW] = array[r][(SIZE-c)*BW-1 -: BW];
        end
    end
endgenerate

endmodule