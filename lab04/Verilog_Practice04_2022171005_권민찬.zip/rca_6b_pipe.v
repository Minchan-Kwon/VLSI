module rca_6b_pipe(
    input clk,
    input rstn,
    input [5:0] a,
    input [5:0] b,
    input cin,
    output [5:0] sum,
    output cout
);
    // Wires
    wire [4:0] carry_lower;
    wire [5:4] carry_upper;
    wire [3:0] sum_s0;
    wire [5:4] a_s1, b_s1;
    
    assign carry_lower[0] = cin;

    // FA
    // Stage 0
    fa u_fa_0(.a(a[0]), .b(b[0]), .cin(carry_lower[0]), .sum(sum_s0[0]), .cout(carry_lower[1]));
    fa u_fa_1(.a(a[1]), .b(b[1]), .cin(carry_lower[1]), .sum(sum_s0[1]), .cout(carry_lower[2]));
    fa u_fa_2(.a(a[2]), .b(b[2]), .cin(carry_lower[2]), .sum(sum_s0[2]), .cout(carry_lower[3]));
    fa u_fa_3(.a(a[3]), .b(b[3]), .cin(carry_lower[3]), .sum(sum_s0[3]), .cout(carry_lower[4]));
    // Stage 1
    fa u_fa_4(.a(a_s1[4]), .b(b_s1[4]), .cin(carry_upper[4]), .sum(sum[4]), .cout(carry_upper[5]));
    fa u_fa_5(.a(a_s1[5]), .b(b_s1[5]), .cin(carry_upper[5]), .sum(sum[5]), .cout(cout));

    // PIPELINE REGISTERS
    // Output registers for 4-bit RCA
    DFF_param #(.WIDTH(4)) reg_sum(.d(sum_s0), .q(sum[3:0]), .clk(clk), .rstn(rstn));

    // Carry register between bit 3 and bit 4
    DFF_param #(.WIDTH(1)) reg_carry(.d(carry_lower[4]), .q(carry_upper[4]), .clk(clk), .rstn(rstn));

    // Input registers for 1-bit FA
    DFF_param #(.WIDTH(2)) reg_a(.d(a[5:4]), .q(a_s1[5:4]), .clk(clk), .rstn(rstn));
    DFF_param #(.WIDTH(2)) reg_b(.d(b[5:4]), .q(b_s1[5:4]), .clk(clk), .rstn(rstn));

endmodule