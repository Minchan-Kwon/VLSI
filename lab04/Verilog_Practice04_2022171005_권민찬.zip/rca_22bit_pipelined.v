module rca_22bit(
    input clk,
    input rstn,
    input [21:0] a, b,
    input cin,
    output [21:0] sum,
    output cout
);
    // WIRE DECLARATIONS
    wire [11:0] carry_lower;
    wire [22:11] carry_upper;
    wire [10:0] sum_stage;  // Connects the first 11 FAs to the pipeline registers
    wire [21:11] a_stage, b_stage;  // Connects the second 11 input bits to the FAs
    wire carry_stage;  // Connects the 11th carry from the DFF to the 12th FA's cin pin

    // Assign initial carry_in
    assign carry_lower[0] = cin;
    // Assign pipeline register output to the upper carry
    assign carry_upper[11] = carry_stage;

    // INSTANTIATE 22 FA MODULES
    genvar i;

    // Generate FA from bits 0 to 10
    generate
        for(i = 0; i < 11; i = i + 1) begin : fa_gen1
            fa u_fa(.a(a[i]), .b(b[i]), .cin(carry_lower[i]),
                .sum(sum_stage[i]), .cout(carry_lower[i+1]));
        end
    endgenerate

    // Generate FA from bits 12 to 21
    generate
        for(i=11; i < 22; i = i + 1) begin: fa_gen2
            fa u_fa(.a(a_stage[i]), .b(b_stage[i]), .cin(carry_upper[i]),
                .sum(sum[i]), .cout(carry_upper[i+1]));
        end
    endgenerate

    // PIPELINE REGISTERS
    // Output FFs for bits 0-10
    DFF_param #(.WIDTH(11)) dff_sum_out (.clk(clk), .rstn(rstn), .d(sum_stage[10:0]), .q(sum[10:0]));  // Sum[10:0] are temporarily stored here

    // FF between u_fa[10] and u_fa[11]
    DFF_param #(.WIDTH(1)) dff_cout (.clk(clk), .rstn(rstn), .d(carry_lower[11]), .q(carry_stage));  // Carry

    // Input FFs for bits 11-21
    DFF_param #(.WIDTH(11)) dff_a_in (.clk(clk), .rstn(rstn), .d(a[21:11]), .q(a_stage[21:11]));  // a[11:21] are temporarily stored here
    DFF_param #(.WIDTH(11)) dff_b_in (.clk(clk), .rstn(rstn), .d(b[21:11]), .q(b_stage[21:11]));  // b[11:21] are temporarily stored here

    // Assign carry_out
    assign cout = carry_upper[22];
endmodule
