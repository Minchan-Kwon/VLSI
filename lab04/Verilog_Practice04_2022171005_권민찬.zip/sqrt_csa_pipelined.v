module sqrt_csa(
    input clk,
    input rstn,
    input [21:0]  a,
    input [21:0]  b,
    input         cin,
    output [21:0] sum,
    output        cout
);
    // Wires
    wire [4:0]  carry0;    // cout when cin = 0
    wire [4:0]  carry1;    // cout when cin = 1
    wire [4:0]  carry_sel; // Select bit (=carry) from the previous adder
    wire [21:2] sum_internal0, sum_internal1; // First two bits are connected directly from 'rca0'

    // Additional wires for pipelining
    wire [1:0] rca0_sum;
    wire [3:2] mux0_sum;
    wire [6:4] mux1_sum;
    wire mux1_carry;
    wire [4:0] rca03_out, rca13_out;


    // First Adder (LSBs)
    multibit_rca #(.WIDTH(2)) rca0 (
        .a(a[1:0]), .b(b[1:0]), .cin(cin), 
        .sum(rca0_sum[1:0]), .cout(carry_sel[0])
    );

    // Carry = 0 
    multibit_rca #(.WIDTH(2)) rca01 (
        .a(a[3:2]),   .b(b[3:2]),   .cin(1'b0), 
        .sum(sum_internal0[3:2]),   .cout(carry0[0])
    );
    multibit_rca #(.WIDTH(3)) rca02 (
        .a(a[6:4]),   .b(b[6:4]),   .cin(1'b0), 
        .sum(sum_internal0[6:4]),   .cout(carry0[1])
    );
    multibit_rca #(.WIDTH(4)) rca03 (
        .a(a[10:7]),  .b(b[10:7]),  .cin(1'b0), 
        .sum(rca03_out[3:0]),  .cout(rca03_out[4])
    );

    // Pipelined 5-bit and 6-bit RCAs
    rca_5b_pipe rca04 (
        .clk(clk), .rstn(rstn),
        .a(a[15:11]), .b(b[15:11]), .cin(1'b0), 
        .sum(sum_internal0[15:11]), .cout(carry0[3])
    );
    rca_6b_pipe rca05 (
        .clk(clk), .rstn(rstn),
        .a(a[21:16]), .b(b[21:16]), .cin(1'b0), 
        .sum(sum_internal0[21:16]), .cout(carry0[4])
    );

    // Carry = 1
    multibit_rca #(.WIDTH(2)) rca11 (
        .a(a[3:2]),   .b(b[3:2]),   .cin(1'b1), 
        .sum(sum_internal1[3:2]),   .cout(carry1[0])
    );
    multibit_rca #(.WIDTH(3)) rca12 (
        .a(a[6:4]),   .b(b[6:4]),   .cin(1'b1), 
        .sum(sum_internal1[6:4]),   .cout(carry1[1])
    );
    multibit_rca #(.WIDTH(4)) rca13 (
        .a(a[10:7]),  .b(b[10:7]),  .cin(1'b1), 
        .sum(rca13_out[3:0]),  .cout(rca13_out[4])
    );

    // Pipelined 5-bit and 6-bit RCAs
    rca_5b_pipe rca14 (
        .clk(clk), .rstn(rstn),
        .a(a[15:11]), .b(b[15:11]), .cin(1'b1), 
        .sum(sum_internal1[15:11]), .cout(carry1[3])
    );
    rca_6b_pipe rca15 (
        .clk(clk), .rstn(rstn),
        .a(a[21:16]), .b(b[21:16]), .cin(1'b1), 
        .sum(sum_internal1[21:16]), .cout(carry1[4])
    );

    // Muxes
    // mux0: 2-bit sum + 1-bit carry = 3 bits
    mux_param #(.WIDTH(3)) mux0 (
        .i0({carry0[0], sum_internal0[3:2]}), 
        .i1({carry1[0], sum_internal1[3:2]}), 
        .sel(carry_sel[0]), 
        .out({carry_sel[1], mux0_sum[3:2]})
    );
    
    // mux1: 3-bit sum + 1-bit carry = 4 bits
    mux_param #(.WIDTH(4)) mux1 (
        .i0({carry0[1], sum_internal0[6:4]}), 
        .i1({carry1[1], sum_internal1[6:4]}), 
        .sel(carry_sel[1]), 
        .out({mux1_carry, mux1_sum[6:4]})
    );
    
    // mux2: 4-bit sum + 1-bit carry = 5 bits
    mux_param #(.WIDTH(5)) mux2 (
        .i0({carry0[2], sum_internal0[10:7]}), 
        .i1({carry1[2], sum_internal1[10:7]}), 
        .sel(carry_sel[2]), 
        .out({carry_sel[3], sum[10:7]})
    );

    // mux3: 5-bit sum + 1-bit carry = 6 bits
    mux_param #(.WIDTH(6)) mux3 (
        .i0({carry0[3], sum_internal0[15:11]}), 
        .i1({carry1[3], sum_internal1[15:11]}), 
        .sel(carry_sel[3]), 
        .out({carry_sel[4], sum[15:11]})
    );

    // mux4: 6-bit sum + 1-bit carry = 7 bits
    mux_param #(.WIDTH(7)) mux4 (
        .i0({carry0[4], sum_internal0[21:16]}), 
        .i1({carry1[4], sum_internal1[21:16]}), 
        .sel(carry_sel[4]), 
        .out({cout, sum[21:16]})
    );

    // PIPELINE REGISTERS
    // STAGE0: 2-bit sum = 2-bit register
    DFF_param #(.WIDTH(2)) rca0_reg(.clk(clk), .rstn(rstn), .d(rca0_sum[1:0]), .q(sum[1:0]));

    // STAGE1: 2-bit sum = 2-bit register
    DFF_param #(.WIDTH(2)) mux0_reg(.clk(clk), .rstn(rstn), .d(mux0_sum[3:2]), .q(sum[3:2]));

    // STAGE2: 3-bit sum + 1-bit carry = 4-bit register
    DFF_param #(.WIDTH(4)) mux1_reg(.clk(clk), .rstn(rstn), .d({mux1_carry, mux1_sum[6:4]}), .q({carry_sel[2], sum[6:4]}));

    // STAGE3: 4-bit sum + 1-bit carry = 5-bit register * 2
    DFF_param #(.WIDTH(5)) rca03_reg(.clk(clk), .rstn(rstn), .d(rca03_out[4:0]), .q({carry0[2], sum_internal0[10:7]}));
    DFF_param #(.WIDTH(5)) rca13_reg(.clk(clk), .rstn(rstn), .d(rca13_out[4:0]), .q({carry1[2], sum_internal1[10:7]}));



endmodule
