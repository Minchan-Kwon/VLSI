module DFF_21bit(
    input [20:0]  d,
    input         clk,
    input         rstn,
    output reg [20:0] q
);
    always @(posedge clk) begin
        if (!rstn) begin
            q <= 21'b0;
        end
        else begin
            q <= d;
        end
    end
endmodule