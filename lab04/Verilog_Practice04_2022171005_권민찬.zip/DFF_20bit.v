module DFF_20bit(
    input [19:0]  d,
    input         clk,
    input         rstn,
    output reg [19:0] q
);
    always @(posedge clk) begin
        if (!rstn) begin
            q <= 20'b0;
        end
        else begin
            q <= d;
        end
    end
endmodule