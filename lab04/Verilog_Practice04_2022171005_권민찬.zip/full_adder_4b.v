module full_adder_4b(
    input [3:0]  a,
    input [3:0]  b,
    input        c_in,
    output [3:0] sum,
    output       c_out
);
    wire [4:0] carry;
    // Assign initial carry_in
    assign carry[0] = c_in;

    // Instantiate FA modules
    genvar i;
    generate 
        for(i = 0; i < 4; i = i + 1) begin : fa_gen
            fa u_fa(.a(a[i]), .b(b[i]), .cin(carry[i]), 
                .sum(sum[i]), .cout(carry[i+1]));
        end
    endgenerate

    // Assign carry_out
    assign c_out = carry[4];

endmodule