module ControlUnit(
    input        clk,
    input        rstn,
    output [1:0] TF_MUX_1,
    output       TF_MUX_2,
    output       BU_MUX_1,
    output       BU_MUX_2,
    output       BU_MUX_3
);
    reg [2:0] counter;
    reg       RUN;

    // Counter
    always @(posedge clk) begin
        if (!rstn) begin
            counter <= 3'b0;
            RUN <= 1'b0;
        end
        else begin
            RUN <= 1'b1;
            if (RUN)  // Delay incrementing the counter by 1 cycle
                counter <= counter + 1'b1;
        end
    end

    // MUX Signals
    // The values of these signals are decided combinationally
    // based on the current counter value.
    assign BU_MUX_1 = counter[2];
    assign BU_MUX_2 = ~(counter[1] ^ counter[0]);
    assign BU_MUX_3 = counter[0];
    assign TF_MUX_1 = ~counter[2] & (counter[1:0]);
    assign TF_MUX_2 = counter[1];

endmodule