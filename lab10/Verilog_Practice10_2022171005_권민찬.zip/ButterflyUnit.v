module ButterflyUnit(
    input  [31:0] A,
    input  [31:0] B,
    output [31:0] C1,
    output [31:0] C2
);  
    wire signed [16:0] C1_R_SUM, C1_I_SUM;
    wire signed [16:0] C2_R_SUM, C2_I_SUM;

    // C1: Addition
    assign C1_R_SUM = $signed(A[31:16]) + $signed(B[31:16]);
    assign C1_I_SUM = $signed(A[15:0]) + $signed(B[15:0]);

    // C2: Subtraction
    assign C2_R_SUM = $signed(A[31:16]) - $signed(B[31:16]);
    assign C2_I_SUM = $signed(A[15:0]) - $signed(B[15:0]);

    // Truncate
    assign C1 = {C1_R_SUM[16:1], C1_I_SUM[16:1]};
    assign C2 = {C2_R_SUM[16:1], C2_I_SUM[16:1]};
endmodule