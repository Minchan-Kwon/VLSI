module ComplexMultiplier(
    input  [31:0] C,
    input  [31:0] T,
    output [31:0] O
);
    wire signed [32:0] O_R, O_I;
    wire signed [15:0] C_R, C_I, T_R, T_I;

    // Assign Real/Imaginary Bits 
    assign {C_R, C_I} = C;
    assign {T_R, T_I} = T;

    // Multiplication
    assign O_R = C_R*T_R - C_I*T_I;  // Real
    assign O_I = C_R*T_I + C_I*T_R;  // Imaginary

    assign O = {O_R[29:14], O_I[29:14]};
endmodule