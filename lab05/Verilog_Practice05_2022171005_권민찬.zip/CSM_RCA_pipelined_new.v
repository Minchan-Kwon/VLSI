module CSM_RCA_pipelined_new(
    input         clk,
    input         rstn,
    input  [21:0] a,
    input  [21:0] b,
    output [43:0] mul
);
    // Stage 1 wires (rows 0 to 11)
    wire [21:0] a_and_s1 [0:12]; 
    wire [20:0] pproduct_s1[0:11];
    wire [21:0] carry_s1[0:11];
    wire [12:0] mul_LSB_s1; // LSB 0~12

    // Stage 1 'and_gates' units to prepare operands for the adder
    genvar i;
    generate
        for (i = 0; i <= 12; i = i + 1) begin : gen_and_s1
            and_gates u_and(.a(a), .b(b[i]), .out(a_and_s1[i]));
        end
    endgenerate

    // The 0th bit of the first AND unit is the 0th bit of the output
    assign mul_LSB_s1[0] = a_and_s1[0][0];

    // 1st row
    adder_22bit_wide_carry u_adder0(
        .a(a_and_s1[1]), .b({1'b0, a_and_s1[0][21:1]}), .cin(22'b0), 
        .sum({pproduct_s1[0], mul_LSB_s1[1]}), .cout(carry_s1[0])
    );

    // 2nd to 12th row
    generate
        for (i = 1; i < 12; i = i + 1) begin : gen_adder_s1
            adder_22bit_wide_carry u_adder(
                .a(a_and_s1[i+1]), 
                .b({1'b0, pproduct_s1[i-1]}), 
                .cin(carry_s1[i-1]), 
                .sum({pproduct_s1[i], mul_LSB_s1[i+1]}), 
                .cout(carry_s1[i])
            );
        end
    endgenerate

    // Wires for pipelining
    wire [20:0] pproduct_pipe;
    wire [21:0] carry_pipe;
    wire [12:0] mul_LSB_pipe;
    wire [21:0] a_pipe;
    wire [21:13]  b_pipe;

    // Save the stage 1 results
    DFF_param #(.WIDTH(21)) reg_pproduct(.clk(clk), .rstn(rstn), .d(pproduct_s1[11]), .q(pproduct_pipe));
    DFF_param #(.WIDTH(22)) reg_carry(.clk(clk), .rstn(rstn), .d(carry_s1[11]), .q(carry_pipe));
    DFF_param #(.WIDTH(13)) reg_mul_LSB(.clk(clk), .rstn(rstn), .d(mul_LSB_s1), .q(mul_LSB_pipe));
    
    // Input values to be used in stage 2
    DFF_param #(.WIDTH(22)) reg_a(.clk(clk), .rstn(rstn), .d(a), .q(a_pipe));
    DFF_param #(.WIDTH(9)) reg_b(.clk(clk), .rstn(rstn), .d(b[21:13]), .q(b_pipe));

    // Stage 2 wires (row 12 to 20)
    wire [21:0] a_and_s2 [13:21];
    wire [20:0] pproduct_s2[12:20];
    wire [21:0] carry_s2[12:20];
    wire [21:13] mul_LSB_s2;

    // 'and_gates' units for stage 2. These are operands for the stage 2 adders
    generate
        for (i = 13; i < 22; i = i + 1) begin : gen_and_s2
            and_gates u_and(.a(a_pipe), .b(b_pipe[i]), .out(a_and_s2[i]));
        end
    endgenerate

    // 13th row
    adder_22bit_wide_carry u_adder12(
        .a(a_and_s2[13]), 
        .b({1'b0, pproduct_pipe}), 
        .cin(carry_pipe), 
        .sum({pproduct_s2[12], mul_LSB_s2[13]}), 
        .cout(carry_s2[12])
    );

    // 14th to 21st row
    generate
        for (i = 13; i <= 20; i = i + 1) begin : gen_adder_s2
            adder_22bit_wide_carry u_adder(
                .a(a_and_s2[i+1]), 
                .b({1'b0, pproduct_s2[i-1]}), 
                .cin(carry_s2[i-1]), 
                .sum({pproduct_s2[i], mul_LSB_s2[i+1]}), 
                .cout(carry_s2[i])
            );
        end
    endgenerate

    // Vector merging adder
    wire [43:22] mul_MSB; // The 22 MSBs of the output

    rca_22bit vec_merge(
        .a({carry_s2[20][21:1], 1'b0}), 
        .b({1'b0, pproduct_s2[20][20:0]}), 
        .cin(carry_s2[20][0]), 
        .sum(mul_MSB), 
        .cout()
    );

    // mul_MSB: output of vec_merge
    // mul_LSB_s2: output of stage 2 adder LSBs
    // mul_LSB_pipe: the registered stage 1 adder LSBs
    assign mul = {mul_MSB, mul_LSB_s2, mul_LSB_pipe};

endmodule