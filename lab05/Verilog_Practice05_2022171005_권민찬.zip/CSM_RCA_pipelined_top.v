module CSM_RCA_pipelined_top(
    input             clk,
    input             rstn,
    input      [21:0] a,
    input      [21:0] b,
    output reg [43:0] mul
);
    // Wires and regs
    reg [21:0] a_reg, b_reg;
    wire [43:0] mul_wire;

    // Instantiate 22-bit carry save multiplier
    CSM_RCA_pipelined_new csm_rca_pipe(.clk(clk), .rstn(rstn), .a(a_reg), .b(b_reg), .mul(mul_wire));

    // Add FFs for the input output stage 
    always @(posedge clk) begin
        if (!rstn) begin
            a_reg <= 22'b0;
            b_reg <= 22'b0;
            mul <= 22'b0;
        end
        else begin
            a_reg <= a;
            b_reg <= b;
            mul <= mul_wire;
        end
    end
endmodule