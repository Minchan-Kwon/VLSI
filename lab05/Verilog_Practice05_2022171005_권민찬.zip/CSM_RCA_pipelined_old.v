module CSM_RCA_pipelined(
    input         clk,
    input         rstn,
    input  [21:0] a,
    input  [21:0] b,
    output [43:0] mul
);
    // Wire Definitions 
    wire [21:0] a_and [0:21];    // 22 22-bit wires for and gate results
    wire [20:0] pproduct[0:20];  // 21 21-bit wires for partial products(sum port of previous row adders) to the next row of adders
    wire [21:0] carry[0:20];     // 21 22-bit wires for the carry connection to the subsequent row of adders
    
    // Additional wires for pipelining 
    wire [21:0] mul_LSB_pipe;
    wire [21:0] carry_pipe;
    wire [20:0] pproduct_pipe;

    // Registers for pipelining
    DFF_param #(.WIDTH(22)) mul_LSB_reg(.clk(clk), .rstn(rstn), .d(mul_LSB_pipe), .q(mul[21:0]));  //Register for the 22 LSBs
    // Carry registers before the vector merging adder
    DFF_param #(.WIDTH(22)) carry_pipe_reg(.clk(clk), .rstn(rstn), .d(carry[20]), .q(carry_pipe));
    // Partial product registers before the vector merging adder
    DFF_param #(.WIDTH(21)) pproduct_pipe_reg(.clk(clk), .rstn(rstn), .d(pproduct[20]), .q(pproduct_pipe));
    
    // Generate 22 'and_gates' units to prepare the operand for the adder
    genvar i;
    generate
        for (i = 0; i < 22; i = i + 1) begin : gen_and
            and_gates u_and(.a(a), .b(b[i]), .out(a_and[i]));
        end
    endgenerate

    // The 0th bit of the first and unit is the 0th bit of the output
    assign mul_LSB_pipe[0] = a_and[0][0];

    // There are 21 rows of 22-bit adders
    // 1st row
    adder_22bit_wide_carry u_adder0(.a(a_and[1]), .b({1'b0, a_and[0][21:1]}), .cin(22'b0), .sum({pproduct[0], mul_LSB_pipe[1]}), .cout(carry[0]));

    // 2nd to 21st Row
    generate
        for (i = 1; i < 21; i = i + 1) begin : gen_adder
            adder_22bit_wide_carry u_adder(.a(a_and[i+1]), 
                                           .b({1'b0, pproduct[i-1]}), 
                                           .cin(carry[i-1]), 
                                           .sum({pproduct[i], mul_LSB_pipe[i+1]}), 
                                           .cout(carry[i]));
        end
    endgenerate

    // Vector merging adder
    // cout port deliberately left unconnected
    // This is another viable connection: .a(carry[20]), .cin(1'b0)
    rca_22bit vec_merge(.a({carry_pipe[21:1], 1'b0}), .b({1'b0, pproduct_pipe[20:0]}), .cin(carry_pipe[0]), .sum(mul[43:22]), .cout());

endmodule