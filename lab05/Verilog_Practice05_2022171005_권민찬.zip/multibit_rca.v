module multibit_rca #(parameter WIDTH = 4) (
    input [WIDTH-1:0] a, b,
    input cin,
    output [WIDTH-1:0] sum,
    output cout
);
    wire [WIDTH:0] carry;
    // Assign initial carry_in
    assign carry[0] = cin;

    // Instantiate FA modules
    genvar i;
    generate 
        for(i = 0; i < WIDTH; i = i + 1) begin : fa_gen
            fa u_fa(.a(a[i]), .b(b[i]), .cin(carry[i]), 
                .sum(sum[i]), .cout(carry[i+1]));
        end
    endgenerate

    // Assign carry_out
    assign cout = carry[WIDTH];
endmodule
