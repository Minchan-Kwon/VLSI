module and_gates(
    input  [21:0] a,
    input         b,
    output [21:0] out
);
    // AND gates
    and(out[0], a[0], b);
    and(out[1], a[1], b);
    and(out[2], a[2], b);
    and(out[3], a[3], b);
    and(out[4], a[4], b);
    and(out[5], a[5], b);
    and(out[6], a[6], b);
    and(out[7], a[7], b);
    and(out[8], a[8], b);
    and(out[9], a[9], b);
    and(out[10], a[10], b);
    and(out[11], a[11], b);
    and(out[12], a[12], b);
    and(out[13], a[13], b);
    and(out[14], a[14], b);
    and(out[15], a[15], b);
    and(out[16], a[16], b);
    and(out[17], a[17], b);
    and(out[18], a[18], b);
    and(out[19], a[19], b);
    and(out[20], a[20], b);
    and(out[21], a[21], b);

endmodule