module mux_param #(parameter WIDTH = 4)(
    input [WIDTH-1:0]  i0,
    input [WIDTH-1:0]  i1,
    input              sel,
    output [WIDTH-1:0] out
);
    // Wires
    wire            sel_not;   
    wire [WIDTH-1:0]  and0, and1;

    // Invert the select bit
    not(sel_not, sel);


    // Generate 1-bit AND and OR gates. 
    // Using a generate loop is necessary for parametrized bit widths.  
    genvar i;
    generate
        for (i = 0; i < WIDTH; i = i + 1) begin : mux_gen
            and(and0[i], sel_not, i0[i]);
            and(and1[i], sel, i1[i]);
            or(out[i], and0[i], and1[i]);
        end
    endgenerate

endmodule
