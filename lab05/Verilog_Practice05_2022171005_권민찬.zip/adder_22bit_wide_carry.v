module adder_22bit_wide_carry(
    input  [21:0] a,
    input  [21:0] b,
    input  [21:0] cin, // Carry from the previous row of adders
    output [21:0] sum,
    output [21:0] cout // Carry to the next row of adders
);
    // Instantiate 22 FA modules
    // Carry does not propagate through the FA units
    // The generated carry is connected straight to the output port
    genvar i;
    generate 
        for(i = 0; i < 22; i = i + 1) begin : fa_gen
            fa u_fa(.a(a[i]), .b(b[i]), .cin(cin[i]), 
                .sum(sum[i]), .cout(cout[i]));
        end
    endgenerate
endmodule