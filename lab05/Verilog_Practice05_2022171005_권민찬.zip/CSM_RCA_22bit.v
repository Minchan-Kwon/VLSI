module CSM_RCA_22bit(
    input  [21:0] a,
    input  [21:0] b,
    output [43:0] mul
);
    // Wire Definitions 
    wire [21:0] a_and [0:21];    // 22 22-bit wires for and gate results
    wire [20:0] pproduct[0:20];  // 21 21-bit wires for partial products(sum port of previous row adders) to the next row of adders
    wire [21:0] carry[0:20];     // 21 22-bit wires for the carry connection to the subsequent row of adders
    
    // Generate 22 'and_gates' units to prepare the operand for the adder
    genvar i;
    generate
        for (i = 0; i < 22; i = i + 1) begin : gen_and
            and_gates u_and(.a(a), .b(b[i]), .out(a_and[i]));
        end
    endgenerate

    // The 0th bit of the first and unit is the 0th bit of the output
    assign mul[0] = a_and[0][0];

    // There are 21 rows of 22-bit adders
    // 1st row
    adder_22bit_wide_carry u_adder0(.a(a_and[1]), .b({1'b0, a_and[0][21:1]}), .cin(22'b0), .sum({pproduct[0], mul[1]}), .cout(carry[0]));

    // 2nd to 21st Row
    generate
        for (i = 1; i < 21; i = i + 1) begin : gen_adder
            adder_22bit_wide_carry u_adder(.a(a_and[i+1]), .b({1'b0, pproduct[i-1]}), .cin(carry[i-1]), .sum({pproduct[i], mul[i+1]}), .cout(carry[i]));
        end
    endgenerate

    // Vector merging adder
    // cout port deliberately left unconnected
    // This is another viable connection: .a(carry[20]), .cin(1'b0)
    rca_22bit vec_merge(.a({carry[20][21:1], 1'b0}), .b({1'b0, pproduct[20][20:0]}), .cin(carry[20][0]), .sum(mul[43:22]), .cout());

endmodule