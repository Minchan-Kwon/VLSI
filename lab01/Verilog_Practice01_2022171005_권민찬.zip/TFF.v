module TFF(
    input clk,
    input rst_n,
    output q
);
wire d;

DFF dff0(.clk(clk), .rst_n(rst_n), .d(d), .q(q));
not n1(d, q);

endmodule
