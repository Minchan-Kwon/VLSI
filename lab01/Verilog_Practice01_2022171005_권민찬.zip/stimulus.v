module stimulus;

reg clk, rst_n;
wire [7:0] q_rcc;
wire [7:0] q_abc;

ripple_carry_counter_8bit counter_rpl(.clk(clk), .rst_n(rst_n), .q(q_rcc));
adder_based_counter_8bit counter_adr(.clk(clk), .rst_n(rst_n), .q(q_abc));

initial 
    clk = 1'b0;
always 
    #5 clk = ~clk;

initial 
begin
rst_n = 1'b0;
#15 rst_n = 1'b1;
#60 rst_n = 1'b0;
#10 rst_n = 1'b1;
#680 $stop;
end

endmodule 