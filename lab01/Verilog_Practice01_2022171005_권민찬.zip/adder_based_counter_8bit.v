module adder_based_counter_8bit(
    input clk,
    input rst_n,
    output reg [7:0] q
);

always @(negedge clk) begin
    if (!rst_n) q <= 8'b00000000;
    else q <= q + 1;
end
endmodule
