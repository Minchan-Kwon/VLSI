module ripple_carry_counter_8bit(
	input clk,
	input rst_n,
	output [7:0] q
);
	TFF tff0(.clk(clk), .rst_n(rst_n), .q(q[0]));
	TFF tff1(.clk(q[0]), .rst_n(rst_n), .q(q[1]));
	TFF tff2(.clk(q[1]), .rst_n(rst_n), .q(q[2]));
	TFF tff3(.clk(q[2]), .rst_n(rst_n), .q(q[3]));
	TFF tff4(.clk(q[3]), .rst_n(rst_n), .q(q[4]));
	TFF tff5(.clk(q[4]), .rst_n(rst_n), .q(q[5]));
	TFF tff6(.clk(q[5]), .rst_n(rst_n), .q(q[6]));
	TFF tff7(.clk(q[6]), .rst_n(rst_n), .q(q[7]));
endmodule