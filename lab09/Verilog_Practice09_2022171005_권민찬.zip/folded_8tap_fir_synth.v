module folded_8tap_fir_synth(
    input                clk_slow,
    input                clk_fast,
    input                rstn,
    input                MUX_ACC,
    input                MUX_OUT,
    input          [2:0] MUX_X,
    input          [2:0] MUX_COEF,
    input  signed [13:0] d_in,
    input  signed [13:0] c0, c1, c2, c3, c4, c5, c6, c7,
    output signed [23:0] result
);
    // Coefficient Registers
    // We only need to store coefficients because the filter module
    // already has registers for the input and output data.
    reg signed [13:0] c0_q, c1_q, c2_q, c3_q, c4_q, c5_q, c6_q, c7_q;
    wire signed [13:0] din_delayed;

    always @(posedge clk_slow) begin
        if (!rstn) begin
            c0_q <= 14'b0;
            c1_q <= 14'b0;
            c2_q <= 14'b0;
            c3_q <= 14'b0;
            c4_q <= 14'b0;
            c5_q <= 14'b0;
            c6_q <= 14'b0;
            c7_q <= 14'b0;
        end
        else begin
            c0_q <= c0;
            c1_q <= c1;
            c2_q <= c2;
            c3_q <= c3;
            c4_q <= c4;
            c5_q <= c5;
            c6_q <= c6;
            c7_q <= c7;
        end
    end

    // Delay Line
    delay_line X_delay(.clk(clk_slow), .rstn(rstn), .sel(MUX_X), .d_in(d_in), .d_out(din_delayed));

    // Folded FIR Filter
    folded_8tap_fir FOLDED_FIR(
        .clk(clk_fast),
        .rstn(rstn),
        .MUX_ACC(MUX_ACC),
        .MUX_OUT(MUX_OUT),
        .MUX_COEF(MUX_COEF),
        .d_in(din_delayed),
        .c0(c0_q), .c1(c1_q), .c2(c2_q), .c3(c3_q), 
        .c4(c4_q), .c5(c5_q), .c6(c6_q), .c7(c7_q),
        .result(result));

endmodule