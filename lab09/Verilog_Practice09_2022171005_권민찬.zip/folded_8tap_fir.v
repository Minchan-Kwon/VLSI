module folded_8tap_fir(
    input                clk, // Fast clock
    input                rstn,
    input                MUX_ACC,
    input                MUX_OUT,
    input          [2:0] MUX_COEF,
    input  signed [13:0] d_in,
    input  signed [13:0] c0, c1, c2, c3, c4, c5, c6, c7,
    output signed [23:0] result
);
    // Registers
    reg signed [13:0] coef;
    reg signed [13:0] X_n;
    reg signed [24:0] acc;
    reg signed [24:0] d_out;
    
    // Wires
    wire signed [13:0] coef_mux;
    wire signed [27:0] product;
    wire signed [21:0] product_round;
    wire signed [24:0] acc_mux;
    wire signed [24:0] out_mux;


    // Sequential Logic
    always @(posedge clk) begin
        if (!rstn) begin
            coef  <= 14'b0;
            X_n   <= 14'b0;
            acc   <= 25'b0;
            d_out <= 25'b0;
        end
        else begin
            coef  <= coef_mux;
            X_n   <= d_in;
            acc   <= product_round + acc_mux;
            d_out <= out_mux;
        end
    end

    // Coefficient MUX
    assign coef_mux = (MUX_COEF == 3'b000) ? c0 :
                      (MUX_COEF == 3'b001) ? c1 :
                      (MUX_COEF == 3'b010) ? c2 :
                      (MUX_COEF == 3'b011) ? c3 :
                      (MUX_COEF == 3'b100) ? c4 :
                      (MUX_COEF == 3'b101) ? c5 :
                      (MUX_COEF == 3'b110) ? c6 :
                      (MUX_COEF == 3'b111) ? c7 : 14'bx;

    // Multiplication
    assign product = coef * X_n;

    // Rounding Units
    round_unit R0(.in(product), .out(product_round));

    // Accumulation MUX
    assign acc_mux = MUX_ACC ? acc : 0;
    
    // Output MUX
    assign out_mux = MUX_OUT ? d_out : acc;

    // Output Assignment
    assign result = d_out;

endmodule