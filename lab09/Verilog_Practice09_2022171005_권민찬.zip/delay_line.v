module delay_line(
    input                clk,  // Slow clock
    input                rstn,
    input          [2:0] sel,
    input  signed [13:0] d_in,
    output signed [13:0] d_out
);
    // The numbers represent k in X[n-k]
    reg signed [13:0] X_n0, X_n1, X_n2, X_n3, X_n4, X_n5, X_n6, X_n7;

    // Delay line clocked by 'clk_slow'
    always @(posedge clk) begin
        if (!rstn) begin
            X_n0 <= 14'b0;
            X_n1 <= 14'b0;
            X_n2 <= 14'b0;
            X_n3 <= 14'b0;
            X_n4 <= 14'b0;
            X_n5 <= 14'b0;
            X_n6 <= 14'b0;
            X_n7 <= 14'b0;
        end
        else begin
            X_n0 <= d_in;
            X_n1 <= X_n0;
            X_n2 <= X_n1;
            X_n3 <= X_n2;
            X_n4 <= X_n3;
            X_n5 <= X_n4;
            X_n6 <= X_n5;
            X_n7 <= X_n6;
        end
    end

    // 8-to-1 MUX
    // Must be driven by a proper select signal from the control unit
    assign d_out = (sel == 3'b000) ? X_n0 :
                   (sel == 3'b001) ? X_n1 :
                   (sel == 3'b010) ? X_n2 :
                   (sel == 3'b011) ? X_n3 :
                   (sel == 3'b100) ? X_n4 :
                   (sel == 3'b101) ? X_n5 :
                   (sel == 3'b110) ? X_n6 :
                   (sel == 3'b111) ? X_n7 : 14'bx;

endmodule