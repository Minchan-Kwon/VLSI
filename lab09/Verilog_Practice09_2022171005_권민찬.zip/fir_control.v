module fir_control(
    input            clk,  // Fast clock
    input            rstn,
    input            start_flag,
    output reg       MUX_ACC,
    output reg       MUX_OUT,
    output reg [2:0] MUX_X,
    output reg [2:0] MUX_COEF
);
    reg [2:0] counter;
    reg RUN;

    always @(posedge clk) begin
        if (!rstn) begin
            counter <= 1'b0;
        end
        else if (start_flag) begin
            counter <= counter + 1'b1;
        end
    end

    always @(*) begin
        if (counter == 3'b1) begin
            MUX_ACC = 1'b0;
            MUX_OUT = 1'b0;
        end
        else begin
            MUX_ACC = 1'b1;
            MUX_OUT = 1'b1;
        end
    end

    assign MUX_X = counter;
    assign MUX_COEF = counter;

endmodule