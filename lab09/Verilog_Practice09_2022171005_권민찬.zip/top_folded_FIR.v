module top_folded_FIR(
    input               clk_slow,
    input               clk_fast,
    input               rstn,
    input signed [13:0] c0, c1, c2, c3, c4, c5, c6, c7
);

    // Memory Controller Wires
    wire       sync;
    wire       rNWRT, wNWRT;
    wire       rNCE,  wNCE;
    wire [7:0] rADDR, wADDR;

    // FIR Controller Wires
    wire       MUX_ACC, MUX_OUT;
    wire [2:0] MUX_X, MUX_COEF;

    // Memory Wires
    wire [13:0] din_mem;

    // FIR Wires
    wire [13:0] din_delayed;
    wire [23:0] dout_fir;



    // Delay Line
    delay_line X_delay(.clk(clk_slow), .rstn(rstn), .sel(MUX_X), .d_in(din_mem), .d_out(din_delayed));

    // Controller
    mem_control MEM_CONTROL(
        .clk        (clk_slow),
        .rstn       (rstn),
        .start_flag (sync),
        .rNWRT      (rNWRT),
        .wNWRT      (wNWRT),
        .rNCE       (rNCE),
        .wNCE       (wNCE),
        .rADDR      (rADDR),
        .wADDR      (wADDR)
    );

    fir_control FIR_CONTROL(
        .clk        (clk_fast),
        .rstn       (rstn),
        .start_flag (sync),
        .MUX_ACC    (MUX_ACC),
        .MUX_OUT    (MUX_OUT),
        .MUX_X      (MUX_X),
        .MUX_COEF   (MUX_COEF)
    );

    // Input Memory
    rflp256x14mx4 INPUT_MEM(
        .NWRT (rNWRT), 
        .DIN  (24'b0),
        .RA   (rADDR[7:2]), 
        .CA   (rADDR[1:0]),
        .NCE  (rNCE), 
        .CLK  (clk_slow), 
        .DO   (din_mem)
    );

    // FIR Filter
    folded_8tap_fir FIR(
        .clk(clk_fast),
        .rstn(rstn),
        .MUX_ACC(MUX_ACC),
        .MUX_OUT(MUX_OUT),
        .MUX_COEF(MUX_COEF),
        .d_in(din_delayed),
        .c0(c0), .c1(c1), .c2(c2), .c3(c3),
        .c4(c4), .c5(c5), .c6(c6), .c7(c7),
        .result(dout_fir)
    );

    // Write Memory
    rflp256x24mx4 OUTPUT_MEM(
        .NWRT (wNWRT), 
        .DIN  (dout_fir), 
        .RA   (wADDR[7:2]), 
        .CA   (wADDR[1:0]), 
        .NCE  (wNCE), 
        .CLK  (clk_slow), 
        .DO   ()
    );


endmodule