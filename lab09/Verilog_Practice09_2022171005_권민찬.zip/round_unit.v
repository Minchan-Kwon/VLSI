module round_unit(
    input  signed [27:0] in,
    output signed [21:0] out
);
    assign out = in[4] ? in[26:5] + 1'b1 : in[26:5];
endmodule