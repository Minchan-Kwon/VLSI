module mem_control(
    input        clk,  // Slow clock
    input        rstn,
    output reg   start_flag,
    output reg   rNWRT,
    output reg   wNWRT,
    output reg   rNCE,
    output reg   wNCE,
    output [7:0] rADDR,
    output [7:0] wADDR

);
    reg [8:0] addr_counter;

    always @(posedge clk) begin
        if (!rstn) begin
            rNWRT <= 1'b1;
            wNWRT <= 1'b1;
            rNCE  <= 1'b1;
            wNCE  <= 1'b1;
            addr_counter <= 9'b0;
            start_flag <= 1'b0;
        end
        else begin
            // Set start_flag to 1
            if (!start_flag) begin
                start_flag <= 1'b1;
            end
            // Counter Increment Logic
            // Must stop counting after accessing memory address 255
            else if (addr_counter <= 9'd265) begin
                addr_counter <= addr_counter + 1'b1;
            end

            // Read Memory Control
            rNWRT <= 1'b1; // Always Read Mode
            // Read memory is enabled until address 255 is accessed.
            // Memory is disabled afterwards to block illegal access.
            if (addr_counter < 9'd255) begin
                rNCE <= 1'b0;   // Turns on the moment addr_counter == 255
            end
            else begin
                rNCE <= 1'b1;
            end

            // Write Memory Control
            // Wait 10 cycles for the output to become valid.
            // Disable write memory after memory write to address 255 occurs.
            if (addr_counter >= 9'd9 && addr_counter < 9'd265) begin
                wNWRT <= 1'b0;
                wNCE  <= 1'b0;      // High when addr_counter is between 10-265
            end
            else begin
                // The memory is disabled after the counter becomes 265 (255 + 10).
                wNWRT <= 1'b1;
                wNCE  <= 1'b1;
            end
        end
    end

    assign rADDR = addr_counter[7:0];
    assign wADDR = addr_counter[7:0] - 8'd10;

endmodule