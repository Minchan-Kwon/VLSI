module controller(
    input         clk,
    input         rstn,
    input         start,
    output reg    rNWRT, rNCE,
    output reg    wNWRT, wNCE,
    output reg    DELAY_EN,
    output reg    MUX_MAC,
    output  [1:0] MUX_C,
    output [11:0] ADDR_A,
    output  [9:0] ADDR_B,
    output [11:0] ADDR_C,
    output reg    DONE
);
    reg RUN;
    reg [16:0] counter;

    // Reset and RUN Logic
    always @(posedge clk) begin
        if (!rstn) begin
            counter <= 17'b0;
            rNWRT <= 1'b1;
            rNCE <= 1'b1;
            wNWRT <= 1'b1;
            wNCE <= 1'b1;
            DELAY_EN <= 1'b0;   // DFF Enable
            MUX_MAC <= 1'b0;    // 0: Reset, 1: Accumulate
            RUN <= 1'b0;
            DONE <= 1'b0;
        end
        else begin
            // MM just started
            if (start) begin
                counter <= 17'b0;
                RUN <= 1'b1;
                DONE <= 1'b0;
                rNCE <= 1'b0;
                rNWRT <= 1'b1;
                wNWRT <= 1'b1;
                wNCE <= 1'b1;
                DELAY_EN <= 1'b0;
                MUX_MAC <= 1'b1;
            end
            // MM is running
            else if (RUN) begin
                // Increment Counter
                counter <= counter + 1'b1;

                // Disable Read
                if (counter == 17'd65535) begin
                    rNCE <= 1'b1;
                end

                // Don't write in the beginning
                if (counter[16:6]==11'b000_0000_0000) begin
                    if (counter[5:0] == 6'b00_0001) MUX_MAC <= 1'b0;
                    else MUX_MAC <= 1'b1;
                    wNWRT <= 1'b1;
                    wNCE <= 1'b1;
                    DELAY_EN <= 1'b0;
                end
                // Write, MUX_MAC, Delay Line Enable Logic
                else begin
                    if (counter[5:0] == 6'b00_0001) begin
                        MUX_MAC <= 1'b0;    // Reset accumulation to 0
                        wNWRT <= 1'b0;
                        wNCE <= 1'b0;
                        DELAY_EN <= 1'b1;
                    end
                    else if (counter[5:0] == 6'b00_0010) begin
                        MUX_MAC <= 1'b1;
                        wNWRT <= 1'b0;
                        wNCE <= 1'b0;
                        DELAY_EN <= 1'b1;
                    end
                    else if (counter[5:0] == 6'b00_0011) begin
                        MUX_MAC <= 1'b1;
                        wNWRT <= 1'b0;
                        wNCE <= 1'b0;
                        DELAY_EN <= 1'b1;
                    end
                    else if (counter[5:0] == 6'b00_0100) begin
                        MUX_MAC <= 1'b1;
                        wNWRT <= 1'b0;
                        wNCE <= 1'b0;
                        DELAY_EN <= 1'b1;
                    end
                    else begin
                        MUX_MAC <= 1'b1;
                        wNWRT <= 1'b1;
                        wNCE <= 1'b1;
                        DELAY_EN <= 1'b0;
                    end
                end

                // DONE Logic
                if (counter == 17'd65541) begin 
                    RUN <= 1'b0;
                    DONE <= 1'b1;
                    counter <= 17'b0;
                    wNWRT <= 1'b1;
                    wNCE <= 1'b1;
                    DELAY_EN <= 1'b0;
                    MUX_MAC <= 1'b0;
                end
            end
            // Reset is off, but haven't started yet
            else begin
                DONE <= 1'b0;
                counter <= 17'b0;
            end
        end
    end

    // Address Logic
    assign ADDR_A = {counter[15:10], counter[5:0]};
    assign ADDR_B = {counter[5:0], counter[9:6]};

    wire [9:0] c_upper = counter[15:6] - 10'b1;
    wire       c_offset_h = ~counter[1];
    wire       c_offset_l = counter[0];
    assign ADDR_C = {c_upper, c_offset_h, c_offset_l};

    // MUX Select Logic 
    // 4-to-1 MUX
    assign MUX_C = {c_offset_h, c_offset_l};

endmodule