module DFF_22b(
    input             clk,
    input             rstn,
    input             en,
    input      [21:0] d,
    output reg [21:0] q
);
    always @(posedge clk) begin
        if (!rstn) begin
            q <= 22'b0;
        end
        else if (en) begin
            q <= d;
        end
    end

endmodule