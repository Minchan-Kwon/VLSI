module top_controller_synth(
    input  clk,
    input  rstn,
    input  start,
    output done
);
    // Controller signals
    wire rNWRT, rNCE;
    wire wNWRT, wNCE;
    wire DELAY_EN;
    wire MUX_MAC;
    wire [1:0]  MUX_C_sel;
    wire [11:0] ADDR_A;
    wire [9:0]  ADDR_B;
    wire [11:0] ADDR_C;
    
    // SRAM Data outputs
    wire [7:0]  mem_a_q;
    wire [31:0] mem_b_q;
    
    // Input register outputs
    wire [7:0]  reg_a_out;
    wire [31:0] reg_b_out;
    
    // MAC outputs
    wire [21:0] mac0_out;
    wire [21:0] mac1_out;
    wire [21:0] mac2_out;
    wire [21:0] mac3_out;
    
    // Delay line wires
    wire [21:0] mac1_d0;
    wire [21:0] mac2_d0, mac2_d1;
    wire [21:0] mac3_d0, mac3_d1, mac3_d2;
    
    // MUX output and final C output wire
    wire [21:0] mux_c_out;
    wire [21:0] c_out; 



    // Controller
    controller CONTROL(
        .clk(clk), 
        .rstn(rstn), 
        .start(start),
        .rNWRT(rNWRT),
        .rNCE(rNCE),
        .wNWRT(wNWRT),
        .wNCE(wNCE),
        .DELAY_EN(DELAY_EN),
        .MUX_MAC(MUX_MAC),
        .MUX_C(MUX_C_sel),
        .ADDR_A(ADDR_A),
        .ADDR_B(ADDR_B),
        .ADDR_C(ADDR_C),
        .DONE(done)
    );

    // Input Registers
    DFF_8b  A_IN_REG(
        .clk(clk), 
        .rstn(rstn), 
        .d(mem_a_q), 
        .q(reg_a_out)
    );
    
    DFF_32b B_IN_REG(
        .clk(clk), 
        .rstn(rstn), 
        .d(mem_b_q), 
        .q(reg_b_out)
    );

    // MAC Units
    MAC M0(.clk(clk), .rstn(rstn), .sel(MUX_MAC), .A(reg_a_out), .B(reg_b_out[31:24]), .C(mac0_out));
    MAC M1(.clk(clk), .rstn(rstn), .sel(MUX_MAC), .A(reg_a_out), .B(reg_b_out[23:16]), .C(mac1_out));
    MAC M2(.clk(clk), .rstn(rstn), .sel(MUX_MAC), .A(reg_a_out), .B(reg_b_out[15:8]),  .C(mac2_out));
    MAC M3(.clk(clk), .rstn(rstn), .sel(MUX_MAC), .A(reg_a_out), .B(reg_b_out[7:0]),   .C(mac3_out));

    // MAC Delay Line
    DFF_22b M1_DELAY_0(.clk(clk), .rstn(rstn), .en(DELAY_EN), .d(mac1_out), .q(mac1_d0));

    DFF_22b M2_DELAY_0(.clk(clk), .rstn(rstn), .en(DELAY_EN), .d(mac2_out), .q(mac2_d0));
    DFF_22b M2_DELAY_1(.clk(clk), .rstn(rstn), .en(DELAY_EN), .d(mac2_d0),  .q(mac2_d1));

    DFF_22b M3_DELAY_0(.clk(clk), .rstn(rstn), .en(DELAY_EN), .d(mac3_out), .q(mac3_d0));
    DFF_22b M3_DELAY_1(.clk(clk), .rstn(rstn), .en(DELAY_EN), .d(mac3_d0),  .q(mac3_d1));
    DFF_22b M3_DELAY_2(.clk(clk), .rstn(rstn), .en(DELAY_EN), .d(mac3_d1),  .q(mac3_d2));

    // 4-to-1 MUX
    mux_4to1 MUX_C(
        .i0(mac0_out),
        .i1(mac1_d0), 
        .i2(mac2_d1),
        .i3(mac3_d2),
        .sel(MUX_C_sel), 
        .out(mux_c_out)
    );

    // Additional Output Register for Synthesis
    DFF_22b C_OUT_REG(.clk(clk), .rstn(rstn), .en(1'b1), .d(mux_c_out), .q(c_out));


endmodule