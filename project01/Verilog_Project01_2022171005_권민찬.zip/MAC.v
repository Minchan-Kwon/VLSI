module MAC(
    input         clk,
    input         rstn,
    input         sel,
    input   [7:0] A,
    input   [7:0] B,
    output [21:0] C
);
    wire [21:0] p_product;
    wire [21:0] mux_out;
    reg  [21:0] acc;

    assign p_product = A * B;
    assign mux_out = (sel) ? acc : 22'b0;

    always @(posedge clk) begin
        if (!rstn) begin
            acc <= 22'b0;
        end
        else begin
            acc <= mux_out + p_product;
        end
    end

    assign C = acc;
endmodule