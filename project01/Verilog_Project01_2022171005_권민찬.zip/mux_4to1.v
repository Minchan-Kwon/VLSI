module mux_4to1(
    input  [21:0] i0,
    input  [21:0] i1,
    input  [21:0] i2,
    input  [21:0] i3,
    input  [1:0]  sel,
    output [21:0] out 
);
    assign out = (sel == 2'b00) ? i0 :
                 (sel == 2'b01) ? i1 :
                 (sel == 2'b10) ? i2 : i3;
endmodule