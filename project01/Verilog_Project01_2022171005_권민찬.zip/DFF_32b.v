module DFF_32b(
    input             clk,
    input             rstn,
    input      [31:0] d,
    output reg [31:0] q
);
    always @(posedge clk) begin
        if (!rstn) begin
            q <= 32'b0;
        end
        else begin
            q <= d;
        end
    end

endmodule