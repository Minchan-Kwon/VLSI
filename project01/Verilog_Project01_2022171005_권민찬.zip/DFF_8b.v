module DFF_8b(
    input            clk,
    input            rstn,
    input      [7:0] d,
    output reg [7:0] q
);
    always @(posedge clk) begin
        if (!rstn) begin
            q <= 8'b0;
        end
        else begin
            q <= d;
        end
    end

endmodule